package com.steve.stepcut

object BuildConfigInfo {
    const val VERSION = "v2.2"
}
