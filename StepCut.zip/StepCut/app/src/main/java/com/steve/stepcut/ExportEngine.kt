package com.steve.stepcut

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.DefaultGainProvider
import androidx.media3.common.audio.GainProcessor
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.common.util.Clock
import androidx.media3.datasource.DataSourceBitmapLoader
import androidx.media3.effect.Presentation
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.mp3.Mp3Extractor
import androidx.media3.extractor.ts.AdtsExtractor
import androidx.media3.transformer.AudioEncoderSettings
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultAssetLoaderFactory
import androidx.media3.transformer.DefaultDecoderFactory
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import java.io.File
import kotlin.math.min

data class ExportParams(
    val videoUri: Uri,
    val songUri: Uri,
    /** Part of the video to keep, in video time. */
    val trimStartSec: Double,
    val trimEndSec: Double,
    /** Video time at which the song file's time 0 plays. */
    val lagSec: Double,
    val songDurSec: Double,
    val corners: FloatArray,
    val pipRect: NRect,
    val outW: Int,
    val outH: Int,
    val fps: Int,
    val scoreImage: File?,
    val scoreSec: Double,
    val videoBitrate: Int,
    /** Opening hook: video-time start of the intense part, or null for no hook. */
    val hookStartSec: Double? = null,
    val hookLenSec: Double = 3.0,
    /** Animated title over the start of the main clip, or null. */
    val title: TitleSpec? = null,
    val titleRenderer: TitleRenderer? = null,
)

/** Runs one export with Media3 Transformer. Must be used from the main thread. */
class ExportEngine(private val context: Context) {
    private val handler = Handler(Looper.getMainLooper())
    private var transformer: Transformer? = null
    private var finished = false

    fun start(params: ExportParams, outFile: File, onProgress: (Int) -> Unit, onDone: (Result<File>) -> Unit) {
        val encoderFactory = DefaultEncoderFactory.Builder(context)
            .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(params.videoBitrate).build())
            .setRequestedAudioEncoderSettings(AudioEncoderSettings.Builder().setBitrate(192_000).build())
            .setEnableFallback(true)
            .build()

        // Exact seeking inside MP3s (needed when the song doesn't start at 0:00 of the clip).
        val extractors = DefaultExtractorsFactory()
            .setMp3ExtractorFlags(Mp3Extractor.FLAG_ENABLE_INDEX_SEEKING)
            .setAdtsExtractorFlags(AdtsExtractor.FLAG_ENABLE_CONSTANT_BITRATE_SEEKING)
        val mediaSourceFactory = DefaultMediaSourceFactory(context, extractors)
            .setEnableClippingInMediaPeriod(true)
        val assetLoaderFactory = DefaultAssetLoaderFactory(
            context,
            DefaultDecoderFactory.Builder(context).build(),
            Clock.DEFAULT,
            mediaSourceFactory,
            DataSourceBitmapLoader.Builder(context).build(),
        )

        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                finish(Result.success(outFile))
            }

            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                val msg = "${exportException.errorCodeName}: ${exportException.message ?: ""}".trim()
                finish(Result.failure(Exception(msg, exportException)))
            }

            private fun finish(r: Result<File>) {
                if (finished) return
                finished = true
                handler.removeCallbacks(poller)
                transformer = null
                onDone(r)
            }
        }

        val t = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoderFactory)
            .setAssetLoaderFactory(assetLoaderFactory)
            .addListener(listener)
            .build()
        transformer = t
        progressCallback = onProgress
        outFile.parentFile?.mkdirs()
        if (outFile.exists()) outFile.delete()
        t.start(buildComposition(params), outFile.absolutePath)
        handler.postDelayed(poller, 300)
    }

    private var progressCallback: ((Int) -> Unit)? = null
    private val progressHolder = ProgressHolder()
    private val poller = object : Runnable {
        override fun run() {
            val t = transformer ?: return
            if (t.getProgress(progressHolder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                progressCallback?.invoke(progressHolder.progress)
            }
            handler.postDelayed(this, 300)
        }
    }

    fun cancel() {
        handler.post {
            handler.removeCallbacks(poller)
            transformer?.cancel()
            transformer = null
        }
    }

    companion object {
        private const val MIN_GAP_US = 1_000L

        private fun songItem(uri: Uri, fromUs: Long, lenUs: Long, fadeInUs: Long, fadeOutUs: Long): EditedMediaItem {
            val media = MediaItem.Builder()
                .setUri(uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionUs(fromUs)
                        .setEndPositionUs(fromUs + lenUs)
                        .build(),
                )
                .build()
            val gain = DefaultGainProvider.Builder(1f)
            if (fadeInUs > 1) gain.addFadeAt(0, fadeInUs, DefaultGainProvider.FADE_IN_LINEAR)
            val outUs = min(fadeOutUs, lenUs / 3)
            if (outUs > 1) gain.addFadeAt(lenUs - outUs, outUs, DefaultGainProvider.FADE_OUT_LINEAR)
            return EditedMediaItem.Builder(media)
                .setRemoveVideo(true)
                .setEffects(Effects(listOf<AudioProcessor>(GainProcessor(gain.build())), emptyList<Effect>()))
                .build()
        }

        fun buildComposition(p: ExportParams): Composition {
            val vsUs = (p.trimStartSec * 1e6).toLong()
            val veUs = (p.trimEndSec * 1e6).toLong()
            val clipUs = veUs - vsUs
            require(clipUs > 500_000) { "The trimmed part is too short." }

            val lagUs = (p.lagSec * 1e6).toLong()
            val songUs = (p.songDurSec * 1e6).toLong() - 30_000L // stay clear of the very end
            val videoItems = mutableListOf<EditedMediaItem>()
            val audio = EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_AUDIO))

            // ---- Hook: the most intense few seconds, ending in a white flash ----
            var hasHook = false
            if (p.hookStartSec != null) {
                val hsUs = (p.hookStartSec * 1e6).toLong()
                val hlUs = (p.hookLenSec * 1e6).toLong()
                val songFrom = hsUs - lagUs
                if (hlUs > 500_000 && songFrom >= 0 && songFrom + hlUs <= songUs) {
                    val hookMedia = MediaItem.Builder()
                        .setUri(p.videoUri)
                        .setClippingConfiguration(
                            MediaItem.ClippingConfiguration.Builder()
                                .setStartPositionUs(hsUs)
                                .setEndPositionUs(hsUs + hlUs)
                                .build(),
                        )
                        .build()
                    val flash = PipEffect(p.corners, p.pipRect, p.outW, p.outH, 0f, 0.14f, p.hookLenSec.toFloat())
                    videoItems += EditedMediaItem.Builder(hookMedia)
                        .setRemoveAudio(true)
                        .setEffects(Effects(emptyList<AudioProcessor>(), listOf<Effect>(flash)))
                        .build()
                    audio.addItem(songItem(p.songUri, songFrom, hlUs, 15_000, 140_000))
                    hasHook = true
                }
            }

            // ---- Main: the trimmed gameplay with the zoomed screen (+ title) ----
            val videoMedia = MediaItem.Builder()
                .setUri(p.videoUri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionUs(vsUs)
                        .setEndPositionUs(veUs)
                        .build(),
                )
                .build()
            val mainEffects = ArrayList<Effect>()
            mainEffects += PipEffect(p.corners, p.pipRect, p.outW, p.outH, if (hasHook) 0.4f else 0f, 0f, 0f)
            if (p.title != null && p.titleRenderer != null) {
                mainEffects += OverlayEffect(listOf<TextureOverlay>(TitleOverlay(p.titleRenderer, p.title)))
            }
            videoItems += EditedMediaItem.Builder(videoMedia)
                .setRemoveAudio(true)
                .setEffects(Effects(emptyList<AudioProcessor>(), mainEffects))
                .build()

            // ---- Score photo ----
            val scoreUs = if (p.scoreImage != null && p.scoreSec > 0) (p.scoreSec * 1e6).toLong() else 0L
            if (scoreUs > 0) {
                val img = MediaItem.Builder()
                    .setUri(Uri.fromFile(p.scoreImage))
                    .setMimeType(MimeTypes.IMAGE_JPEG)
                    .setImageDurationMs(scoreUs / 1000)
                    .build()
                videoItems += EditedMediaItem.Builder(img)
                    .setFrameRate(p.fps)
                    .setEffects(
                        Effects(
                            emptyList<AudioProcessor>(),
                            listOf<Effect>(Presentation.createForWidthAndHeight(p.outW, p.outH, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)),
                        ),
                    )
                    .build()
            }
            val videoSequence = EditedMediaItemSequence.withVideoFrom(videoItems)

            // ---- Audio for the main clip: the clean song lined up with the video ----
            var remaining = clipUs
            var songPos = vsUs - lagUs // position in the song at the start of the clip
            var hasSong = false
            if (songPos < 0) {
                val gap = min(-songPos, remaining)
                if (gap >= MIN_GAP_US) audio.addGap(gap)
                remaining -= gap
                songPos = 0
            }
            if (remaining > 0 && songPos < songUs) {
                val len = min(remaining, songUs - songPos)
                // Fade out only when we cut the song before it ends.
                val cutEarly = songPos + len < songUs - 1_000_000
                audio.addItem(songItem(p.songUri, songPos, len, 15_000, if (cutEarly) 600_000 else 0))
                remaining -= len
                hasSong = true
            }
            require(hasSong) { "The song doesn't overlap the trimmed part of the video." }
            if (remaining >= MIN_GAP_US) audio.addGap(remaining)
            if (scoreUs > 0) audio.addGap(scoreUs)

            return Composition.Builder(videoSequence, audio.build())
                .setHdrMode(Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL)
                .build()
        }
    }
}
