package com.steve.stepcut

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.MediaController
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.card.MaterialCardView
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.slider.Slider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs

    // Inputs
    private var videoUri: Uri? = null
    private var songUri: Uri? = null
    private var scoreUri: Uri? = null

    // Analysis results
    private var videoInfo: VideoInfo? = null
    private var songDurSec = 0.0
    private var sync: SyncResult? = null
    private var nudgeMs = 0
    private var trimStart = 0.0
    private var trimEnd = 0.0
    private var frame: Bitmap? = null

    private var analyzeJob: Job? = null
    private var thumbJob: Job? = null
    private var previewJob: Job? = null
    private var exportJob: Job? = null
    private var savedUri: Uri? = null

    // Views
    private lateinit var txtVideo: TextView
    private lateinit var txtSong: TextView
    private lateinit var txtScore: TextView
    private lateinit var txtStatus: TextView
    private lateinit var progAnalyze: LinearProgressIndicator
    private lateinit var cardSync: MaterialCardView
    private lateinit var cardScreen: MaterialCardView
    private lateinit var cardScore: MaterialCardView
    private lateinit var cardExport: MaterialCardView
    private lateinit var txtSyncInfo: TextView
    private lateinit var txtNudge: TextView
    private lateinit var txtStart: TextView
    private lateinit var txtEnd: TextView
    private lateinit var imgStart: ImageView
    private lateinit var imgEnd: ImageView
    private lateinit var btnQuickTest: MaterialButton
    private lateinit var cornerEditor: CornerEditorView
    private lateinit var imgPreview: ImageView
    private lateinit var sliderSize: Slider
    private lateinit var sliderY: Slider
    private lateinit var groupAlign: MaterialButtonToggleGroup
    private lateinit var groupShape: MaterialButtonToggleGroup
    private lateinit var txtScoreInfo: TextView
    private lateinit var txtScoreSec: TextView
    private lateinit var sliderScoreSec: Slider
    private lateinit var groupScoreBg: MaterialButtonToggleGroup
    private lateinit var groupRes: MaterialButtonToggleGroup
    private lateinit var groupQuality: MaterialButtonToggleGroup
    private lateinit var txtEstimate: TextView
    private lateinit var btnExport: MaterialButton
    private lateinit var progExport: LinearProgressIndicator
    private lateinit var txtExportStatus: TextView
    private lateinit var rowDone: View

    private val pickVideo = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            videoUri = uri
            txtVideo.text = MediaInfo.displayName(this, uri)
            maybeAnalyze()
        }
    }

    private val pickSong = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            songUri = uri
            txtSong.text = MediaInfo.displayName(this, uri)
            maybeAnalyze()
        }
    }

    private val pickScore = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scoreUri = uri
            txtScore.text = MediaInfo.displayName(this, uri)
            updateScoreInfo()
            updateEstimate()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)
        bindViews()
        setupControls()
    }

    private fun bindViews() {
        txtVideo = findViewById(R.id.txtVideo)
        txtSong = findViewById(R.id.txtSong)
        txtScore = findViewById(R.id.txtScore)
        txtStatus = findViewById(R.id.txtStatus)
        progAnalyze = findViewById(R.id.progAnalyze)
        cardSync = findViewById(R.id.cardSync)
        cardScreen = findViewById(R.id.cardScreen)
        cardScore = findViewById(R.id.cardScore)
        cardExport = findViewById(R.id.cardExport)
        txtSyncInfo = findViewById(R.id.txtSyncInfo)
        txtNudge = findViewById(R.id.txtNudge)
        txtStart = findViewById(R.id.txtStart)
        txtEnd = findViewById(R.id.txtEnd)
        imgStart = findViewById(R.id.imgStart)
        imgEnd = findViewById(R.id.imgEnd)
        btnQuickTest = findViewById(R.id.btnQuickTest)
        cornerEditor = findViewById(R.id.cornerEditor)
        imgPreview = findViewById(R.id.imgPreview)
        sliderSize = findViewById(R.id.sliderSize)
        sliderY = findViewById(R.id.sliderY)
        groupAlign = findViewById(R.id.groupAlign)
        groupShape = findViewById(R.id.groupShape)
        txtScoreInfo = findViewById(R.id.txtScoreInfo)
        txtScoreSec = findViewById(R.id.txtScoreSec)
        sliderScoreSec = findViewById(R.id.sliderScoreSec)
        groupScoreBg = findViewById(R.id.groupScoreBg)
        groupRes = findViewById(R.id.groupRes)
        groupQuality = findViewById(R.id.groupQuality)
        txtEstimate = findViewById(R.id.txtEstimate)
        btnExport = findViewById(R.id.btnExport)
        progExport = findViewById(R.id.progExport)
        txtExportStatus = findViewById(R.id.txtExportStatus)
        rowDone = findViewById(R.id.rowDone)
    }

    private val alignIds = intArrayOf(R.id.btnAlignLeft, R.id.btnAlignCenter, R.id.btnAlignRight)
    private val shapeIds = intArrayOf(R.id.btnShapeAuto, R.id.btnShape169, R.id.btnShape43)
    private val resIds = intArrayOf(R.id.btnRes720, R.id.btnRes1080, R.id.btnResSource)
    private val qualityIds = intArrayOf(R.id.btnQStd, R.id.btnQHigh, R.id.btnQMax)

    private fun setupControls() {
        findViewById<View>(R.id.btnVideo).setOnClickListener {
            pickVideo.launch(PickVisualMediaRequest.Builder().setMediaType(ActivityResultContracts.PickVisualMedia.VideoOnly).build())
        }
        findViewById<View>(R.id.btnSong).setOnClickListener { pickSong.launch(arrayOf("audio/*")) }
        findViewById<View>(R.id.btnScore).setOnClickListener {
            pickScore.launch(PickVisualMediaRequest.Builder().setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly).build())
        }

        // Audio nudge
        fun nudge(d: Int) {
            nudgeMs = (nudgeMs + d).coerceIn(-2000, 2000)
            updateNudge()
        }
        findViewById<View>(R.id.btnNudgeM50).setOnClickListener { nudge(-50) }
        findViewById<View>(R.id.btnNudgeM10).setOnClickListener { nudge(-10) }
        findViewById<View>(R.id.btnNudgeP10).setOnClickListener { nudge(10) }
        findViewById<View>(R.id.btnNudgeP50).setOnClickListener { nudge(50) }

        // Trim
        fun moveStart(d: Double) {
            val dur = videoInfo?.durationSec ?: return
            trimStart = (trimStart + d).coerceIn(0.0, max(0.0, min(dur, trimEnd) - 1.0))
            updateTrim()
        }
        fun moveEnd(d: Double) {
            val dur = videoInfo?.durationSec ?: return
            trimEnd = (trimEnd + d).coerceIn(min(dur, trimStart + 1.0), dur)
            updateTrim()
        }
        findViewById<View>(R.id.btnStartM1).setOnClickListener { moveStart(-1.0) }
        findViewById<View>(R.id.btnStartM01).setOnClickListener { moveStart(-0.1) }
        findViewById<View>(R.id.btnStartP01).setOnClickListener { moveStart(0.1) }
        findViewById<View>(R.id.btnStartP1).setOnClickListener { moveStart(1.0) }
        findViewById<View>(R.id.btnEndM1).setOnClickListener { moveEnd(-1.0) }
        findViewById<View>(R.id.btnEndM01).setOnClickListener { moveEnd(-0.1) }
        findViewById<View>(R.id.btnEndP01).setOnClickListener { moveEnd(0.1) }
        findViewById<View>(R.id.btnEndP1).setOnClickListener { moveEnd(1.0) }

        btnQuickTest.setOnClickListener { quickTest() }

        // Screen corners
        cornerEditor.setCorners(prefs.corners)
        cornerEditor.onCornersChanged = { refreshPreview(fast = true) }
        cornerEditor.onEditFinished = {
            prefs.corners = cornerEditor.corners.copyOf()
            refreshPreview(fast = false)
        }
        findViewById<View>(R.id.btnResetCorners).setOnClickListener {
            cornerEditor.setCorners(PipGeometry.DEFAULT_CORNERS)
            prefs.corners = PipGeometry.DEFAULT_CORNERS.copyOf()
            refreshPreview(fast = false)
        }

        // PIP layout
        val pip = prefs.pip
        sliderSize.value = pip.widthPct.toFloat()
        sliderY.value = pip.yPct.toFloat()
        groupAlign.check(alignIds[pip.align])
        groupShape.check(shapeIds[pip.shape])
        sliderSize.addOnChangeListener { _, _, _ -> savePip() }
        sliderY.addOnChangeListener { _, _, _ -> savePip() }
        groupAlign.addOnButtonCheckedListener { _, _, isChecked -> if (isChecked) savePip() }
        groupShape.addOnButtonCheckedListener { _, _, isChecked -> if (isChecked) savePip() }

        // Score
        sliderScoreSec.value = ((prefs.scoreSec * 2).roundToInt() / 2f).coerceIn(1f, 10f)
        txtScoreSec.text = "Show for ${fmtSec(sliderScoreSec.value)}"
        sliderScoreSec.addOnChangeListener { _, v, _ ->
            prefs.scoreSec = v
            txtScoreSec.text = "Show for ${fmtSec(v)}"
            updateEstimate()
        }
        groupScoreBg.check(if (prefs.scoreBlur) R.id.btnBgBlur else R.id.btnBgBlack)
        groupScoreBg.addOnButtonCheckedListener { _, id, isChecked -> if (isChecked) prefs.scoreBlur = id == R.id.btnBgBlur }
        updateScoreInfo()

        // Export
        groupRes.check(resIds[prefs.resolution.coerceIn(0, 2)])
        groupQuality.check(qualityIds[prefs.quality.coerceIn(0, 2)])
        groupRes.addOnButtonCheckedListener { _, id, isChecked ->
            if (isChecked) {
                prefs.resolution = resIds.indexOf(id)
                updateEstimate()
            }
        }
        groupQuality.addOnButtonCheckedListener { _, id, isChecked ->
            if (isChecked) {
                prefs.quality = qualityIds.indexOf(id)
                updateEstimate()
            }
        }
        btnExport.setOnClickListener { if (exportJob?.isActive == true) exportJob?.cancel() else export() }
        findViewById<View>(R.id.btnOpen).setOnClickListener {
            savedUri?.let { u ->
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            }
        }
        findViewById<View>(R.id.btnShare).setOnClickListener {
            savedUri?.let { u ->
                val send = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, u)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(Intent.createChooser(send, "Share video"))
            }
        }
    }

    // ---------------------------------------------------------------- analysis

    private fun maybeAnalyze() {
        if (videoUri != null && songUri != null) analyze()
    }

    private fun analyze() {
        val v = videoUri ?: return
        val s = songUri ?: return
        analyzeJob?.cancel()
        cardSync.visibility = View.GONE
        cardScreen.visibility = View.GONE
        cardScore.visibility = View.GONE
        cardExport.visibility = View.GONE
        progAnalyze.visibility = View.VISIBLE
        progAnalyze.setProgressCompat(0, false)
        txtStatus.text = "Reading the video…"

        analyzeJob = lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.Default) {
                    val ctx = this@MainActivity
                    val job = coroutineContext[Job]
                    val check: () -> Unit = { job?.ensureActive() }
                    val info = MediaInfo.readVideo(ctx, v)
                    status("Listening to the video's audio…", 0f)
                    val rec = try {
                        AudioFeatureExtractor.extract(ctx, v, check) { p -> status("Listening to the video's audio…", p * 0.6f) }
                    } catch (e: NoAudioException) {
                        throw Exception("The video has no sound, so the song can't be matched to it.")
                    }
                    status("Listening to the song…", 0.6f)
                    val song = AudioFeatureExtractor.extract(ctx, s, check) { p -> status("Listening to the song…", 0.6f + p * 0.3f) }
                    status("Matching the song to the video…", 0.92f)
                    val sync = AudioSync.align(rec, song, info.durationSec)
                    check()
                    status("Grabbing a frame…", 0.97f)
                    val mid = (sync.songStartSec + sync.songEndSec) / 2
                    val frame = MediaInfo.frameAt(ctx, v, mid, 1080, info, exact = false)
                        ?: throw Exception("Couldn't read a frame from the video.")
                    Analysis(info, song.durationSec, sync, frame)
                }
                applyAnalysis(result)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                txtStatus.text = "Something went wrong: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                progAnalyze.visibility = View.GONE
            }
        }
    }

    private class Analysis(val info: VideoInfo, val songDur: Double, val sync: SyncResult, val frame: Bitmap)

    private fun status(text: String, progress: Float) {
        runOnUiThread {
            txtStatus.text = text
            progAnalyze.setProgressCompat((progress * 100).roundToInt().coerceIn(0, 100), true)
        }
    }

    private fun applyAnalysis(a: Analysis) {
        videoInfo = a.info
        songDurSec = a.songDur
        sync = a.sync
        nudgeMs = 0
        trimStart = a.sync.songStartSec
        trimEnd = a.sync.songEndSec
        frame = a.frame
        cornerEditor.bitmap = a.frame
        cornerEditor.setCorners(prefs.corners)

        txtStatus.text = "Done. Check the steps below, then export."
        cardSync.visibility = View.VISIBLE
        cardScreen.visibility = View.VISIBLE
        cardScore.visibility = View.VISIBLE
        cardExport.visibility = View.VISIBLE
        rowDone.visibility = View.GONE
        txtExportStatus.text = ""

        val c = a.sync.confidence
        val match = when {
            c >= 1.3 -> "Strong match"
            c >= 1.15 -> "Good match"
            else -> "Weak match. Use Quick test to check, and fine-tune if needed"
        }
        val where = if (a.sync.lagSec >= 0) {
            "The song starts at ${fmtTime(a.sync.lagSec)} in your video."
        } else {
            "Your recording started ${fmtSec(-a.sync.lagSec)} into the song."
        }
        txtSyncInfo.text = "$where\n$match (${"%.2f".format(Locale.US, c)}).\nSuggested clip: ${fmtTime(trimStart)} → ${fmtTime(trimEnd)}"
        updateNudge()
        updateTrim()
        refreshPreview(fast = false)
        updateEstimate()
    }

    private fun updateNudge() {
        txtNudge.text = when {
            nudgeMs == 0 -> "0 ms"
            nudgeMs > 0 -> "+$nudgeMs ms\n(later)"
            else -> "$nudgeMs ms\n(earlier)"
        }
    }

    private fun updateTrim() {
        txtStart.text = fmtTime(trimStart)
        txtEnd.text = fmtTime(trimEnd)
        updateEstimate()
        val v = videoUri ?: return
        val info = videoInfo ?: return
        thumbJob?.cancel()
        thumbJob = lifecycleScope.launch {
            delay(250)
            val s = trimStart
            val e = trimEnd
            val (a, b) = withContext(Dispatchers.IO) {
                MediaInfo.frameAt(this@MainActivity, v, s, 240, info, exact = true) to
                    MediaInfo.frameAt(this@MainActivity, v, max(s, e - 0.05), 240, info, exact = true)
            }
            imgStart.setImageBitmap(a)
            imgEnd.setImageBitmap(b)
        }
    }

    // ---------------------------------------------------------------- PIP preview

    private fun currentPip() = PipSettings(
        sliderSize.value.roundToInt(),
        sliderY.value.roundToInt(),
        alignIds.indexOf(groupAlign.checkedButtonId).coerceAtLeast(0),
        shapeIds.indexOf(groupShape.checkedButtonId).coerceAtLeast(0),
    )

    private fun savePip() {
        prefs.pip = currentPip()
        refreshPreview(fast = false)
    }

    private fun pipRectFor(outW: Int, outH: Int): NRect {
        val f = frame
        val pip = currentPip()
        val aspect = if (f != null) {
            PipGeometry.pipAspect(pip, cornerEditor.corners, f.width, f.height)
        } else {
            16f / 9f
        }
        return PipGeometry.pipRect(outW, outH, pip, aspect)
    }

    private fun refreshPreview(fast: Boolean) {
        val f = frame ?: return
        val info = videoInfo ?: return
        val corners = cornerEditor.corners.copyOf()
        val rect = pipRectFor(info.width, info.height)
        previewJob?.cancel()
        previewJob = lifecycleScope.launch {
            if (fast) delay(60)
            val bmp = withContext(Dispatchers.Default) {
                PreviewRenderer.render(f, corners, rect, if (fast) 360 else 720)
            }
            imgPreview.setImageBitmap(bmp)
        }
    }

    // ---------------------------------------------------------------- score

    private fun updateScoreInfo() {
        txtScoreInfo.text = if (scoreUri == null) {
            "No score photo picked, so the video will end with the gameplay. Pick one in step 1 to add it."
        } else {
            "The score photo is shown after the gameplay."
        }
    }

    // ---------------------------------------------------------------- export

    private fun outputSize(info: VideoInfo, res: Int): Pair<Int, Int> {
        val short = min(info.width, info.height)
        val target = when (res) {
            0 -> 720
            1 -> 1080
            else -> short
        }.coerceAtMost(short)
        val scale = target.toDouble() / short
        var w = (info.width * scale).roundToInt()
        var h = (info.height * scale).roundToInt()
        val longSide = max(w, h)
        if (longSide > 3840) {
            val k = 3840.0 / longSide
            w = (w * k).roundToInt()
            h = (h * k).roundToInt()
        }
        return (w / 2 * 2) to (h / 2 * 2)
    }

    private fun bitrateFor(w: Int, h: Int, fps: Int, quality: Int): Int {
        val bpp = when (quality) {
            0 -> 0.08
            1 -> 0.13
            else -> 0.22
        }
        return (w.toDouble() * h * fps * bpp).toInt().coerceIn(1_000_000, 60_000_000)
    }

    private fun clipSeconds(): Double {
        val score = if (scoreUri != null) sliderScoreSec.value.toDouble() else 0.0
        return (trimEnd - trimStart) + score
    }

    private fun updateEstimate() {
        val info = videoInfo ?: return
        val res = resIds.indexOf(groupRes.checkedButtonId).coerceAtLeast(0)
        val q = qualityIds.indexOf(groupQuality.checkedButtonId).coerceAtLeast(0)
        val (w, h) = outputSize(info, res)
        val br = bitrateFor(w, h, info.fps, q)
        val secs = clipSeconds()
        val mb = (br + 192_000) * secs / 8 / 1_000_000
        txtEstimate.text = "Output: ${w}×$h, ${info.fps} fps · ${fmtTime(secs)} long · ≈ ${mb.roundToInt()} MB"
    }

    private fun buildParams(outW: Int, outH: Int, bitrate: Int, start: Double, end: Double, scoreFile: File?): ExportParams {
        val info = videoInfo!!
        val s = sync!!
        return ExportParams(
            videoUri = videoUri!!,
            songUri = songUri!!,
            trimStartSec = start,
            trimEndSec = end,
            lagSec = s.lagSec + nudgeMs / 1000.0,
            songDurSec = songDurSec,
            corners = cornerEditor.corners.copyOf(),
            pipRect = pipRectFor(outW, outH),
            outW = outW,
            outH = outH,
            fps = info.fps,
            scoreImage = scoreFile,
            scoreSec = if (scoreFile != null) sliderScoreSec.value.toDouble() else 0.0,
            videoBitrate = bitrate,
        )
    }

    private fun export() {
        val info = videoInfo ?: return
        if (sync == null) return
        val res = resIds.indexOf(groupRes.checkedButtonId).coerceAtLeast(0)
        val q = qualityIds.indexOf(groupQuality.checkedButtonId).coerceAtLeast(0)
        val (outW, outH) = outputSize(info, res)
        val bitrate = bitrateFor(outW, outH, info.fps, q)
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val score = scoreUri
        val blur = prefs.scoreBlur

        setBusy(true)
        rowDone.visibility = View.GONE
        progExport.visibility = View.VISIBLE
        progExport.setProgressCompat(0, false)
        txtExportStatus.text = "Preparing…"
        btnExport.text = "Cancel"

        exportJob = lifecycleScope.launch {
            var scoreFile: File? = null
            val outFile = File(cacheDir, "stepcut_$stamp.mp4")
            try {
                if (score != null) {
                    txtExportStatus.text = "Preparing the score photo…"
                    scoreFile = withContext(Dispatchers.IO) {
                        File(cacheDir, "score_$stamp.jpg").also { ScoreImageRenderer.render(this@MainActivity, score, outW, outH, blur, it) }
                    }
                }
                val params = buildParams(outW, outH, bitrate, trimStart, trimEnd, scoreFile)
                txtExportStatus.text = "Exporting… keep the app open."
                runExport(params, outFile) { p ->
                    progExport.setProgressCompat(p, true)
                    txtExportStatus.text = "Exporting… $p% (keep the app open)"
                }
                txtExportStatus.text = "Saving to your gallery…"
                val uri = withContext(Dispatchers.IO) { MediaInfo.saveToGallery(this@MainActivity, outFile, "StepCut_$stamp.mp4") }
                savedUri = uri
                txtExportStatus.text = "Saved to Movies/StepCut as StepCut_$stamp.mp4"
                rowDone.visibility = View.VISIBLE
            } catch (e: CancellationException) {
                txtExportStatus.text = "Export cancelled."
            } catch (e: Exception) {
                txtExportStatus.text = "Export failed: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                withContext(Dispatchers.IO + kotlinx.coroutines.NonCancellable) {
                    outFile.delete()
                    scoreFile?.delete()
                }
                progExport.visibility = View.GONE
                btnExport.text = "Export video"
                setBusy(false)
            }
        }
    }

    private fun quickTest() {
        val info = videoInfo ?: return
        if (sync == null) return
        if (exportJob?.isActive == true) return
        val (outW, outH) = outputSize(info, 0)
        val mid = (trimStart + trimEnd) / 2
        val s = max(trimStart, mid - 5)
        val e = min(trimEnd, s + 10)
        setBusy(true)
        btnExport.isEnabled = false
        btnQuickTest.text = "Making test clip…"
        exportJob = lifecycleScope.launch {
            val outFile = File(cacheDir, "quicktest.mp4")
            try {
                val params = buildParams(outW, outH, 4_000_000, s, e, null)
                runExport(params, outFile) { p -> btnQuickTest.text = "Making test clip… $p%" }
                showVideoDialog(outFile)
            } catch (ce: CancellationException) {
                // ignore
            } catch (ex: Exception) {
                Toast.makeText(this@MainActivity, "Test failed: ${ex.message}", Toast.LENGTH_LONG).show()
            } finally {
                btnQuickTest.text = "Quick test (10 s clip)"
                btnExport.isEnabled = true
                setBusy(false)
            }
        }
    }

    private suspend fun runExport(params: ExportParams, outFile: File, onProgress: (Int) -> Unit): File =
        suspendCancellableCoroutine { cont ->
            val engine = ExportEngine(this)
            cont.invokeOnCancellation { engine.cancel() }
            try {
                engine.start(params, outFile, onProgress) { result ->
                    if (cont.isActive) {
                        result.fold({ cont.resume(it) }, { cont.resumeWithException(it) })
                    }
                }
            } catch (e: Exception) {
                if (cont.isActive) cont.resumeWithException(e)
            }
        }

    private fun showVideoDialog(file: File) {
        val videoView = VideoView(this)
        val container = FrameLayout(this)
        container.setPadding(0, 24, 0, 0)
        container.addView(
            videoView,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, android.view.Gravity.CENTER),
        )
        val controller = MediaController(this)
        controller.setAnchorView(videoView)
        videoView.setMediaController(controller)
        videoView.setVideoPath(file.absolutePath)
        videoView.setOnPreparedListener { it.isLooping = true; videoView.start() }
        AlertDialog.Builder(this)
            .setTitle("Quick test")
            .setMessage("Does the music line up with your steps? If not, use the fine-tune buttons and test again.")
            .setView(container)
            .setPositiveButton("Close") { d, _ -> d.dismiss() }
            .setOnDismissListener { videoView.stopPlayback() }
            .show()
    }

    private fun setBusy(busy: Boolean) {
        if (busy) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        btnQuickTest.isEnabled = !busy
        findViewById<View>(R.id.btnVideo).isEnabled = !busy
        findViewById<View>(R.id.btnSong).isEnabled = !busy
        findViewById<View>(R.id.btnScore).isEnabled = !busy
    }

    // ---------------------------------------------------------------- formatting

    private fun fmtTime(sec: Double): String {
        val s = max(0.0, sec)
        val m = (s / 60).toInt()
        val rest = s - m * 60
        return String.format(Locale.US, "%d:%04.1f", m, rest)
    }

    private fun fmtSec(sec: Float): String = fmtSec(sec.toDouble())

    private fun fmtSec(sec: Double): String =
        if (abs(sec - sec.roundToInt()) < 1e-6) "${sec.roundToInt()} s" else String.format(Locale.US, "%.1f s", sec)
}
