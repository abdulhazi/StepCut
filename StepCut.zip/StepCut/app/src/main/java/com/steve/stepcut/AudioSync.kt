package com.steve.stepcut

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * @param lagSec video time (seconds) at which the song file's time 0 plays.
 * @param confidence ratio of the best match to the best competing match (1.0 = ambiguous).
 * @param correlation average correlation at the best match (0..1, comparable between songs).
 * @param songStartSec / songEndSec where the song plays in the video (suggested trim).
 */
data class SyncResult(
    val lagSec: Double,
    val confidence: Double,
    val correlation: Double,
    val songStartSec: Double,
    val songEndSec: Double,
)

/**
 * Compact description of a piece of audio on a 100 Hz grid.
 * flux: per-band onset envelopes (normalised), onset: overall onset strength, energy: loudness.
 */
class Fingerprint(
    val flux: Array<FloatArray>,
    val onset: FloatArray,
    val energy: FloatArray,
    val startSec: Double,
    val durationSec: Double,
) {
    val size: Int get() = onset.size
}

/**
 * Finds where a clean song plays inside a noisy recording.
 *
 * Both signals are turned into per-band "onset" envelopes (how much the energy jumps in 8
 * frequency ranges, 100 times per second). Beats, drums and note attacks survive speakers,
 * room echo, crowd noise and footsteps, so cross-correlating these envelopes finds the offset.
 */
object AudioSync {
    const val GROUPS = 8
    private const val BANDS_PER_GROUP = AudioFeatures.NBANDS / GROUPS
    const val HZ = AudioFeatures.GRID_HZ

    fun fingerprint(f: AudioFeatures): Fingerprint {
        val n = f.bands.size
        val flux = Array(GROUPS) { FloatArray(n) }
        val onset = FloatArray(n)
        val energy = FloatArray(n)
        for (i in 0 until n) {
            val cur = f.bands[i]
            var e = 0f
            for (b in 0 until AudioFeatures.NBANDS) e += cur[b]
            energy[i] = e / AudioFeatures.NBANDS
            if (i == 0) continue
            val prev = f.bands[i - 1]
            var o = 0f
            for (b in 0 until AudioFeatures.NBANDS) {
                val d = cur[b] - prev[b]
                if (d > 0f) {
                    flux[b / BANDS_PER_GROUP][i] += d
                    o += d
                }
            }
            onset[i] = o
        }
        for (g in 0 until GROUPS) normaliseLocal(flux[g], 100)
        return Fingerprint(flux, onset, energy, f.startSec, f.durationSec)
    }

    private class Peak(val lagFrames: Double, val ratio: Double, val rho: Double)

    /** Cross-correlates two multi-band envelopes. lag L means rec[t] ~ song[t - L]. */
    private fun xcorr(r: Array<FloatArray>, s: Array<FloatArray>, exclusion: Int): Peak {
        val nR = r[0].size
        val nS = s[0].size
        var n = 2
        while (n < nR + nS) n = n shl 1
        val accRe = DoubleArray(n)
        val accIm = DoubleArray(n)
        val aRe = DoubleArray(n)
        val aIm = DoubleArray(n)
        val bRe = DoubleArray(n)
        val bIm = DoubleArray(n)
        for (g in r.indices) {
            aRe.fill(0.0); aIm.fill(0.0); bRe.fill(0.0); bIm.fill(0.0)
            for (i in 0 until nR) aRe[i] = r[g][i].toDouble()
            for (i in 0 until nS) bRe[i] = s[g][i].toDouble()
            Fft.transform(aRe, aIm)
            Fft.transform(bRe, bIm)
            for (k in 0 until n) {
                accRe[k] += aRe[k] * bRe[k] + aIm[k] * bIm[k]
                accIm[k] += aIm[k] * bRe[k] - aRe[k] * bIm[k]
            }
        }
        Fft.transform(accRe, accIm, inverse = true)

        val total = nR + nS - 1
        val vals = DoubleArray(total) { Double.NEGATIVE_INFINITY }
        val overlaps = IntArray(total)
        val minOverlap = min(nR, nS) * 0.25
        for (j in 0 until total) {
            val lag = j - (nS - 1)
            val idx = if (lag >= 0) lag else n + lag
            val overlap = min(nR, lag + nS) - max(0, lag)
            overlaps[j] = overlap
            if (overlap > 0 && overlap >= minOverlap) vals[j] = accRe[idx] / sqrt(overlap.toDouble())
        }
        var best = 0
        for (j in 1 until total) if (vals[j] > vals[best]) best = j
        if (vals[best] == Double.NEGATIVE_INFINITY || vals[best] <= 0.0) return Peak(0.0, 1.0, 0.0)

        var frac = 0.0
        if (best in 1 until total - 1 && vals[best - 1].isFinite() && vals[best + 1].isFinite()) {
            val a = vals[best - 1]; val b = vals[best]; val c = vals[best + 1]
            val den = a - 2 * b + c
            if (abs(den) > 1e-12) frac = (0.5 * (a - c) / den).coerceIn(-0.5, 0.5)
        }
        var second = Double.NEGATIVE_INFINITY
        for (j in 0 until total) {
            if (abs(j - best) <= exclusion) continue
            if (vals[j] > second) second = vals[j]
        }
        val ratio = if (second <= 0.0 || !second.isFinite()) 9.99 else vals[best] / second
        val rho = vals[best] / sqrt(overlaps[best].toDouble()) / r.size
        return Peak((best - (nS - 1)) + frac, ratio, rho)
    }

    /** Fast, rough match score (correlation at 25 Hz) for picking candidate songs. */
    fun coarseScore(rec: Fingerprint, song: Fingerprint): Double {
        val p = xcorr(downsample(rec.flux, 4), downsample(song.flux, 4), 12)
        return p.rho * min(p.ratio, 2.0)
    }

    private fun downsample(x: Array<FloatArray>, k: Int): Array<FloatArray> = Array(x.size) { g ->
        val src = x[g]
        FloatArray(src.size / k) { i ->
            var s = 0f
            for (q in 0 until k) s += src[i * k + q]
            s / k
        }
    }

    fun align(rec: Fingerprint, song: Fingerprint, videoDurSec: Double): SyncResult {
        val r = rec.flux
        val s = song.flux
        val nR = r[0].size
        val nS = s[0].size
        val peak = xcorr(r, s, 50)
        if (peak.rho <= 0.0) throw IllegalStateException("Couldn't find the song in the video's audio.")
        val lagFrames = peak.lagFrames
        val lagSec = rec.startSec - song.startSec + lagFrames / HZ

        // Where does the song actually play? Usually [lag, lag + song length], but the arcade
        // may play a shorter cut, or the song file may have an intro the arcade skips.
        val lagI = lagFrames.roundToInt()
        val expS = max(0, lagI)
        val expE = min(nR, lagI + nS)
        var startF = expS
        var endF = expE
        val win = 100
        val nWin = nR / win
        val sims = DoubleArray(nWin) { Double.NaN }
        for (w in 0 until nWin) {
            val a0 = w * win
            val b0 = a0 - lagI
            if (b0 < 0 || b0 + win > nS) continue
            var sum = 0.0
            for (g in 0 until GROUPS) {
                var num = 0.0; var xx = 0.0; var yy = 0.0
                for (i in 0 until win) {
                    val x = r[g][a0 + i].toDouble()
                    val y = s[g][b0 + i].toDouble()
                    num += x * y; xx += x * x; yy += y * y
                }
                sum += num / (sqrt(xx * yy) + 1e-9)
            }
            sims[w] = sum / GROUPS
        }
        val valid = sims.filter { !it.isNaN() }.sorted()
        if (valid.size >= 6) {
            val upper = valid.subList(valid.size / 2, valid.size)
            val typical = upper[upper.size / 2]
            val thr = 0.35 * typical
            val run = 3
            var first = -1
            var last = -1
            for (w in 0..nWin - run) {
                var ok = true
                for (q in 0 until run) {
                    val v = sims[w + q]
                    if (v.isNaN() || v <= thr) { ok = false; break }
                }
                if (ok) {
                    if (first < 0) first = w
                    last = w
                }
            }
            if (first >= 0) {
                val sC = first * win
                val eC = (last + run) * win
                // Only trust these when they differ a lot (a real cut, not a quiet fade).
                if (sC - expS > 400) startF = max(expS, sC - 50)
                if (expE - eC > 800) endF = min(expE, eC + 300)
            }
        }

        val startSec = (rec.startSec + startF / HZ).coerceIn(0.0, videoDurSec)
        val endSec = (rec.startSec + endF / HZ).coerceIn(startSec, videoDurSec)
        return SyncResult(lagSec, peak.ratio, peak.rho, startSec, endSec)
    }

    /** Removes the 1-second running mean and divides by the running standard deviation. */
    private fun normaliseLocal(x: FloatArray, w: Int) {
        val n = x.size
        val s1 = DoubleArray(n + 1)
        val s2 = DoubleArray(n + 1)
        for (i in 0 until n) {
            s1[i + 1] = s1[i] + x[i]
            s2[i + 1] = s2[i] + x[i].toDouble() * x[i]
        }
        val half = w / 2
        val out = FloatArray(n)
        for (i in 0 until n) {
            val lo = max(0, i - half)
            val hi = min(n, i + half)
            val cnt = (hi - lo).toDouble()
            val mean = (s1[hi] - s1[lo]) / cnt
            val variance = max(0.0, (s2[hi] - s2[lo]) / cnt - mean * mean)
            out[i] = ((x[i] - mean) / (sqrt(variance) + 1e-9)).toFloat()
        }
        System.arraycopy(out, 0, x, 0, n)
    }
}

/** Picks the most intense stretch of the song for the opening hook. */
object HookFinder {
    /**
     * Returns the hook start in VIDEO time, inside [clipStart, clipEnd - lenSec], or null.
     * Uses the clean song's onset density (busy notes) and loudness.
     */
    fun find(song: Fingerprint, lagSec: Double, clipStart: Double, clipEnd: Double, lenSec: Double): Double? {
        val hz = AudioSync.HZ
        val n = song.size
        val win = (lenSec * hz).roundToInt()
        if (win < 10 || n < win + 10) return null
        // Allowed window starts, in song frames: inside the clip, skipping the intro (first 15%).
        val clipLen = clipEnd - clipStart
        val lo = ((clipStart + clipLen * 0.15 - lagSec - song.startSec) * hz).roundToInt().coerceIn(0, n - win)
        val hi = ((clipEnd - lenSec - 0.3 - lagSec - song.startSec) * hz).roundToInt().coerceIn(0, n - win)
        if (hi <= lo) return null

        fun zscore(x: FloatArray): DoubleArray {
            val mean = x.average()
            var v = 0.0
            for (a in x) v += (a - mean) * (a - mean)
            val sd = sqrt(v / x.size) + 1e-9
            return DoubleArray(x.size) { (x[it] - mean) / sd }
        }
        val on = zscore(song.onset)
        val en = zscore(song.energy)
        val pre = DoubleArray(n + 1)
        for (i in 0 until n) pre[i + 1] = pre[i] + on[i] + 0.6 * en[i]
        var best = lo
        var bestScore = Double.NEGATIVE_INFINITY
        for (s in lo..hi) {
            val sc = pre[s + win] - pre[s]
            if (sc > bestScore) {
                bestScore = sc
                best = s
            }
        }
        // Start on a hit: strongest onset within ±0.3 s of the chosen start.
        var snap = best
        val r = (0.3 * hz).toInt()
        for (s in max(lo, best - r)..min(hi, best + r)) if (song.onset[s] > song.onset[snap]) snap = s
        // Begin a hair before the hit so it isn't clipped.
        val startSongSec = (snap - 3).coerceAtLeast(0) / hz + song.startSec
        return startSongSec + lagSec
    }
}
