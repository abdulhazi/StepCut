package com.steve.stepcut

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * @param lagSec video time (seconds) at which the song file's time 0 plays.
 * @param confidence ratio of the best match to the best competing match (1.0 = ambiguous).
 * @param songStartSec / songEndSec where the song plays in the video (suggested trim).
 */
data class SyncResult(
    val lagSec: Double,
    val confidence: Double,
    val songStartSec: Double,
    val songEndSec: Double,
)

/**
 * Finds where a clean song plays inside a noisy recording.
 *
 * Both signals are turned into per-band "onset" envelopes (how much the energy jumps in 8
 * frequency ranges, 100 times per second). Beats, drums and note attacks survive speakers,
 * room echo, crowd noise and footsteps, so cross-correlating these envelopes finds the offset.
 */
object AudioSync {
    private const val GROUPS = 8
    private const val BANDS_PER_GROUP = AudioFeatures.NBANDS / GROUPS
    private const val HZ = AudioFeatures.GRID_HZ

    fun align(rec: AudioFeatures, song: AudioFeatures, videoDurSec: Double): SyncResult {
        val r = groupFlux(rec)
        val s = groupFlux(song)
        val nR = r[0].size
        val nS = s[0].size

        var n = 2
        while (n < nR + nS) n = n shl 1
        val accRe = DoubleArray(n)
        val accIm = DoubleArray(n)
        val aRe = DoubleArray(n)
        val aIm = DoubleArray(n)
        val bRe = DoubleArray(n)
        val bIm = DoubleArray(n)
        for (g in 0 until GROUPS) {
            aRe.fill(0.0); aIm.fill(0.0); bRe.fill(0.0); bIm.fill(0.0)
            for (i in 0 until nR) aRe[i] = r[g][i].toDouble()
            for (i in 0 until nS) bRe[i] = s[g][i].toDouble()
            Fft.transform(aRe, aIm)
            Fft.transform(bRe, bIm)
            for (k in 0 until n) {
                // a * conj(b)
                accRe[k] += aRe[k] * bRe[k] + aIm[k] * bIm[k]
                accIm[k] += aIm[k] * bRe[k] - aRe[k] * bIm[k]
            }
        }
        Fft.transform(accRe, accIm, inverse = true)

        // Score every lag L (rec[t] ~ song[t - L]), normalised by overlap length.
        val total = nR + nS - 1
        val vals = DoubleArray(total) { Double.NEGATIVE_INFINITY }
        val minOverlap = min(nR, nS) * 0.25
        for (j in 0 until total) {
            val lag = j - (nS - 1)
            val idx = if (lag >= 0) lag else n + lag
            val overlap = min(nR, lag + nS) - max(0, lag)
            if (overlap > 0 && overlap >= minOverlap) vals[j] = accRe[idx] / sqrt(overlap.toDouble())
        }
        var best = 0
        for (j in 1 until total) if (vals[j] > vals[best]) best = j
        if (vals[best] == Double.NEGATIVE_INFINITY || vals[best] <= 0.0) {
            throw IllegalStateException("Couldn't find the song in the video's audio.")
        }

        // Sub-frame refinement
        var frac = 0.0
        if (best in 1 until total - 1 && vals[best - 1].isFinite() && vals[best + 1].isFinite()) {
            val a = vals[best - 1]; val b = vals[best]; val c = vals[best + 1]
            val den = a - 2 * b + c
            if (abs(den) > 1e-12) frac = (0.5 * (a - c) / den).coerceIn(-0.5, 0.5)
        }

        // Confidence: best vs best competitor at least 0.5 s away
        var second = Double.NEGATIVE_INFINITY
        for (j in 0 until total) {
            if (abs(j - best) <= 50) continue
            if (vals[j] > second) second = vals[j]
        }
        val confidence = if (second <= 0.0 || !second.isFinite()) 9.99 else vals[best] / second

        val lagFrames = (best - (nS - 1)) + frac
        val lagSec = rec.startSec - song.startSec + lagFrames / HZ

        // Where does the song actually play? Usually [lag, lag + song length], but the arcade
        // may play a shorter cut, or the song file may have an intro the arcade skips.
        val lagI = lagFrames.roundToInt()
        val expS = max(0, lagI)
        val expE = min(nR, lagI + nS)
        var startF = expS
        var endF = expE
        val win = 100
        val nWin = nR / win
        val sims = DoubleArray(nWin) { Double.NaN }
        for (w in 0 until nWin) {
            val a0 = w * win
            val b0 = a0 - lagI
            if (b0 < 0 || b0 + win > nS) continue
            var sum = 0.0
            for (g in 0 until GROUPS) {
                var num = 0.0; var xx = 0.0; var yy = 0.0
                for (i in 0 until win) {
                    val x = r[g][a0 + i].toDouble()
                    val y = s[g][b0 + i].toDouble()
                    num += x * y; xx += x * x; yy += y * y
                }
                sum += num / (sqrt(xx * yy) + 1e-9)
            }
            sims[w] = sum / GROUPS
        }
        val valid = sims.filter { !it.isNaN() }.sorted()
        if (valid.size >= 6) {
            val upper = valid.subList(valid.size / 2, valid.size)
            val typical = upper[upper.size / 2]
            val thr = 0.35 * typical
            val run = 3
            var first = -1
            var last = -1
            for (w in 0..nWin - run) {
                var ok = true
                for (q in 0 until run) {
                    val v = sims[w + q]
                    if (v.isNaN() || v <= thr) { ok = false; break }
                }
                if (ok) {
                    if (first < 0) first = w
                    last = w
                }
            }
            if (first >= 0) {
                val sC = first * win
                val eC = (last + run) * win
                // Only trust these when they differ a lot (a real cut, not a quiet fade).
                if (sC - expS > 400) startF = max(expS, sC - 50)
                if (expE - eC > 800) endF = min(expE, eC + 300)
            }
        }

        val startSec = (rec.startSec + startF / HZ).coerceIn(0.0, videoDurSec)
        val endSec = (rec.startSec + endF / HZ).coerceIn(startSec, videoDurSec)
        return SyncResult(lagSec, confidence, startSec, endSec)
    }

    private fun groupFlux(f: AudioFeatures): Array<FloatArray> {
        val n = f.bands.size
        val out = Array(GROUPS) { FloatArray(n) }
        for (i in 1 until n) {
            val cur = f.bands[i]
            val prev = f.bands[i - 1]
            for (b in 0 until AudioFeatures.NBANDS) {
                val d = cur[b] - prev[b]
                if (d > 0f) out[b / BANDS_PER_GROUP][i] += d
            }
        }
        for (g in 0 until GROUPS) normaliseLocal(out[g], 100)
        return out
    }

    /** Removes the 1-second running mean and divides by the running standard deviation. */
    private fun normaliseLocal(x: FloatArray, w: Int) {
        val n = x.size
        val s1 = DoubleArray(n + 1)
        val s2 = DoubleArray(n + 1)
        for (i in 0 until n) {
            s1[i + 1] = s1[i] + x[i]
            s2[i + 1] = s2[i] + x[i].toDouble() * x[i]
        }
        val half = w / 2
        val out = FloatArray(n)
        for (i in 0 until n) {
            val lo = max(0, i - half)
            val hi = min(n, i + half)
            val cnt = (hi - lo).toDouble()
            val mean = (s1[hi] - s1[lo]) / cnt
            val variance = max(0.0, (s2[hi] - s2[lo]) / cnt - mean * mean)
            out[i] = ((x[i] - mean) / (sqrt(variance) + 1e-9)).toFloat()
        }
        System.arraycopy(out, 0, x, 0, n)
    }
}
