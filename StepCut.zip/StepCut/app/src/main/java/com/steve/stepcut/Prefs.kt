package com.steve.stepcut

import android.content.Context
import androidx.core.content.edit

/** Remembers the screen corners and layout choices between videos. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("stepcut", Context.MODE_PRIVATE)

    var corners: FloatArray
        get() {
            val parts = sp.getString("corners", null)?.split(",")?.mapNotNull { it.toFloatOrNull() }
            return if (parts != null && parts.size == 8) parts.toFloatArray() else PipGeometry.DEFAULT_CORNERS.copyOf()
        }
        set(v) = sp.edit { putString("corners", v.joinToString(",")) }

    var pip: PipSettings
        get() = PipSettings(
            sp.getInt("pipWidth", 62).coerceIn(30, 100),
            sp.getInt("pipY", 22).coerceIn(0, 100),
            sp.getInt("pipAlign", 2).coerceIn(0, 2),
            sp.getInt("pipShape", 0).coerceIn(0, 2),
        )
        set(v) = sp.edit {
            putInt("pipWidth", v.widthPct)
            putInt("pipY", v.yPct)
            putInt("pipAlign", v.align)
            putInt("pipShape", v.shape)
        }

    var scoreSec: Float
        get() = sp.getFloat("scoreSec", 4f)
        set(v) = sp.edit { putFloat("scoreSec", v) }

    var scoreBlur: Boolean
        get() = sp.getBoolean("scoreBlur", true)
        set(v) = sp.edit { putBoolean("scoreBlur", v) }

    /** 0 = 720p, 1 = 1080p, 2 = same as source */
    var resolution: Int
        get() = sp.getInt("res", 1)
        set(v) = sp.edit { putInt("res", v) }

    /** 0 = standard, 1 = high, 2 = max */
    var quality: Int
        get() = sp.getInt("quality", 1)
        set(v) = sp.edit { putInt("quality", v) }
}
