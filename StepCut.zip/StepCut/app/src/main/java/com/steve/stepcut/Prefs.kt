package com.steve.stepcut

import android.content.Context
import androidx.core.content.edit

/** Remembers the screen corners and layout choices between videos. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("stepcut", Context.MODE_PRIVATE)

    var corners: FloatArray
        get() {
            val parts = sp.getString("corners", null)?.split(",")?.mapNotNull { it.toFloatOrNull() }
            return if (parts != null && parts.size == 8) parts.toFloatArray() else PipGeometry.DEFAULT_CORNERS.copyOf()
        }
        set(v) = sp.edit { putString("corners", v.joinToString(",")) }

    var pip: PipSettings
        get() = PipSettings(
            sp.getInt("pipWidth", 62).coerceIn(30, 100),
            sp.getInt("pipY", 22).coerceIn(0, 100),
            sp.getInt("pipAlign", 2).coerceIn(0, 2),
            sp.getInt("pipShape", 0).coerceIn(0, 2),
        )
        set(v) = sp.edit {
            putInt("pipWidth", v.widthPct)
            putInt("pipY", v.yPct)
            putInt("pipAlign", v.align)
            putInt("pipShape", v.shape)
        }

    var scoreSec: Float
        get() = sp.getFloat("scoreSec", 4f)
        set(v) = sp.edit { putFloat("scoreSec", v) }

    var scoreBlur: Boolean
        get() = sp.getBoolean("scoreBlur", true)
        set(v) = sp.edit { putBoolean("scoreBlur", v) }

    /** 0 = 720p, 1 = 1080p, 2 = same as source */
    var resolution: Int
        get() = sp.getInt("res", 1)
        set(v) = sp.edit { putInt("res", v) }

    /** 0 = standard, 1 = high, 2 = max */
    var quality: Int
        get() = sp.getInt("quality", 1)
        set(v) = sp.edit { putInt("quality", v) }

    var libraryUri: String?
        get() = sp.getString("libraryUri", null)
        set(v) = sp.edit { putString("libraryUri", v) }

    var hookOn: Boolean
        get() = sp.getBoolean("hookOn", true)
        set(v) = sp.edit { putBoolean("hookOn", v) }

    var hookLen: Float
        get() = sp.getFloat("hookLen", 3f)
        set(v) = sp.edit { putFloat("hookLen", v) }

    var titleOn: Boolean
        get() = sp.getBoolean("titleOn", true)
        set(v) = sp.edit { putBoolean("titleOn", v) }

    var template: Int
        get() = sp.getInt("template", 0).coerceIn(0, 3)
        set(v) = sp.edit { putInt("template", v) }

    var titlePos: Int
        get() = sp.getInt("titlePos", 2).coerceIn(0, 2)
        set(v) = sp.edit { putInt("titlePos", v) }

    var player: String
        get() = sp.getString("player", "") ?: ""
        set(v) = sp.edit { putString("player", v) }

    /** Remembers the chart (mode + level) you last used for each song. */
    fun chartFor(songKey: String): Pair<Char, Int> {
        val v = sp.getString("chart_$songKey", null) ?: return (sp.getString("lastMode", "S")?.firstOrNull() ?: 'S') to sp.getInt("lastLevel", 18)
        val mode = v.firstOrNull() ?: 'S'
        val level = v.drop(1).toIntOrNull() ?: 18
        return mode to level
    }

    fun setChart(songKey: String, mode: Char, level: Int) = sp.edit {
        putString("chart_$songKey", "$mode$level")
        putString("lastMode", mode.toString())
        putInt("lastLevel", level)
    }

    /** Edited title/artist for a song, so you only fix them once. */
    fun titleFor(songKey: String): Pair<String, String>? {
        val t = sp.getString("title_$songKey", null) ?: return null
        return t to (sp.getString("artist_$songKey", "") ?: "")
    }

    fun setTitle(songKey: String, title: String, artist: String) = sp.edit {
        putString("title_$songKey", title)
        putString("artist_$songKey", artist)
    }
}
