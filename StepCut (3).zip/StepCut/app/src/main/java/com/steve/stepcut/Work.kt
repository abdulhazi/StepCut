package com.steve.stepcut

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/**
 * Keeps StepCut working while it's in the background: a foreground service with a progress
 * notification (and a wake lock) runs whenever an analysis or export is going on.
 */
object AppWork {
    /** Lives as long as the app process, not the screen. */
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    const val CHANNEL_PROGRESS = "progress"
    const val CHANNEL_DONE = "done"
    const val NOTIF_PROGRESS = 1
    const val NOTIF_DONE = 2

    @Volatile var active = 0
        private set
    @Volatile var serviceRunning = false
    private var lastText = "Working…"

    private fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_PROGRESS) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL_PROGRESS, "Progress", NotificationManager.IMPORTANCE_LOW))
        }
        if (nm.getNotificationChannel(CHANNEL_DONE) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL_DONE, "Finished videos", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    private fun openAppIntent(ctx: Context): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(ctx, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun progressNotification(ctx: Context, text: String = lastText, percent: Int = -1): Notification {
        ensureChannels(ctx)
        return Notification.Builder(ctx, CHANNEL_PROGRESS)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("StepCut")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, percent.coerceIn(0, 100), percent < 0)
            .setContentIntent(openAppIntent(ctx))
            .build()
    }

    /** Call when work starts (from the screen, while the app is open). */
    fun begin(ctx: Context, text: String) {
        val app = ctx.applicationContext
        active++
        lastText = text
        try {
            app.startForegroundService(Intent(app, WorkService::class.java))
        } catch (_: Exception) {
            // Not allowed right now (e.g. already in the background): work continues anyway.
        }
    }

    fun update(ctx: Context, text: String, percent: Int = -1) {
        lastText = text
        if (active <= 0 || !serviceRunning) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        try {
            nm.notify(NOTIF_PROGRESS, progressNotification(ctx.applicationContext, text, percent))
        } catch (_: Exception) {
        }
    }

    fun end(ctx: Context) {
        active = (active - 1).coerceAtLeast(0)
        if (active == 0 && serviceRunning) {
            ctx.applicationContext.stopService(Intent(ctx.applicationContext, WorkService::class.java))
        }
    }

    /** A "finished" notification; tapping opens [videoUri] if given, otherwise the app. */
    fun notifyDone(ctx: Context, title: String, text: String, videoUri: Uri?) {
        val app = ctx.applicationContext
        ensureChannels(app)
        val tap = if (videoUri != null) {
            val view = Intent(Intent.ACTION_VIEW).setDataAndType(videoUri, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            PendingIntent.getActivity(app, 1, view, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        } else {
            openAppIntent(app)
        }
        val n = Notification.Builder(app, CHANNEL_DONE)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(tap)
            .build()
        try {
            app.getSystemService(NotificationManager::class.java).notify(NOTIF_DONE, n)
        } catch (_: Exception) {
        }
    }
}

class WorkService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = AppWork.progressNotification(this)
        try {
            val type = if (Build.VERSION.SDK_INT >= 35) TYPE_MEDIA_PROCESSING else ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            startForeground(AppWork.NOTIF_PROGRESS, n, type)
        } catch (_: Exception) {
            try { startForeground(AppWork.NOTIF_PROGRESS, n) } catch (_: Exception) { }
        }
        AppWork.serviceRunning = true
        if (wakeLock == null) {
            wakeLock = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "StepCut:work")
                .apply { acquire(3 * 60 * 60 * 1000L) }
        }
        // Work may have finished before the service got going.
        if (AppWork.active == 0) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        AppWork.serviceRunning = false
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) { }
        wakeLock = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    companion object {
        /** ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING (Android 15+). */
        private const val TYPE_MEDIA_PROCESSING = 0x2000
    }
}
