package com.steve.stepcut

import android.Manifest
import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.MediaController
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.card.MaterialCardView
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.slider.Slider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private val titleRenderer by lazy { TitleRenderer(TitleFonts(applicationContext)) }

    // Inputs
    private var videoUri: Uri? = null
    private var manualSongUri: Uri? = null
    private var scoreUri: Uri? = null

    // Analysis results
    private var videoInfo: VideoInfo? = null
    private var songUri: Uri? = null
    private var songName = ""
    private var songFp: Fingerprint? = null
    private var songMeta: SongMeta? = null
    private var sync: SyncResult? = null
    private var nudgeMs = 0
    private var trimStart = 0.0
    private var trimEnd = 0.0
    private var hookStart: Double? = null
    private var hookCandidates: List<Double> = emptyList()
    private var hookIndex = 0
    private var lastError = ""
    private var frame: Bitmap? = null
    private var previewBase: Bitmap? = null
    private var level = 18
    private var loadingTitleFields = false

    private var analyzeJob: Job? = null
    private var thumbJob: Job? = null
    private var hookThumbJob: Job? = null
    private var previewJob: Job? = null
    private var titleAnimator: ValueAnimator? = null
    private var savedUri: Uri? = null

    // Views
    private lateinit var txtVideo: TextView
    private lateinit var txtSong: TextView
    private lateinit var btnSongFolder: MaterialButton
    private lateinit var btnSongAuto: View
    private lateinit var txtScore: TextView
    private lateinit var txtStatus: TextView
    private lateinit var progAnalyze: LinearProgressIndicator
    private lateinit var cards: List<MaterialCardView>
    private lateinit var txtSyncInfo: TextView
    private lateinit var txtNudge: TextView
    private lateinit var txtStart: TextView
    private lateinit var txtEnd: TextView
    private lateinit var imgStart: ImageView
    private lateinit var imgEnd: ImageView
    private lateinit var btnQuickTest: MaterialButton
    private lateinit var switchHook: MaterialSwitch
    private lateinit var hookBody: View
    private lateinit var txtHookLen: TextView
    private lateinit var sliderHookLen: Slider
    private lateinit var imgHook: ImageView
    private lateinit var txtHook: TextView
    private lateinit var switchTitle: MaterialSwitch
    private lateinit var titleBody: View
    private lateinit var groupTemplate: MaterialButtonToggleGroup
    private lateinit var imgTitlePreview: ImageView
    private lateinit var editTitle: EditText
    private lateinit var editArtist: EditText
    private lateinit var editPlayer: EditText
    private lateinit var groupMode: MaterialButtonToggleGroup
    private lateinit var txtLevel: TextView
    private lateinit var groupTitlePos: MaterialButtonToggleGroup
    private lateinit var cornerEditor: CornerEditorView
    private lateinit var imgPreview: ImageView
    private lateinit var sliderSize: Slider
    private lateinit var sliderY: Slider
    private lateinit var groupAlign: MaterialButtonToggleGroup
    private lateinit var groupShape: MaterialButtonToggleGroup
    private lateinit var txtScoreInfo: TextView
    private lateinit var txtScoreSec: TextView
    private lateinit var sliderScoreSec: Slider
    private lateinit var groupScoreBg: MaterialButtonToggleGroup
    private lateinit var groupRes: MaterialButtonToggleGroup
    private lateinit var groupQuality: MaterialButtonToggleGroup
    private lateinit var txtEstimate: TextView
    private lateinit var btnExport: MaterialButton
    private lateinit var progExport: LinearProgressIndicator
    private lateinit var txtExportStatus: TextView
    private lateinit var rowDone: View
    private lateinit var switchZoom: MaterialSwitch
    private lateinit var zoomBody: View
    private lateinit var zoomControls: View
    private lateinit var btnHookPreview: MaterialButton
    private lateinit var btnCopyError: View

    private val alignIds = intArrayOf(R.id.btnAlignLeft, R.id.btnAlignCenter, R.id.btnAlignRight)
    private val shapeIds = intArrayOf(R.id.btnShapeAuto, R.id.btnShape169, R.id.btnShape43)
    private val resIds = intArrayOf(R.id.btnRes720, R.id.btnRes1080, R.id.btnResSource)
    private val qualityIds = intArrayOf(R.id.btnQStd, R.id.btnQHigh, R.id.btnQMax)
    private val templateIds = intArrayOf(R.id.btnTplNeon, R.id.btnTplArcade, R.id.btnTplGlitch, R.id.btnTplMinimal)
    private val modeIds = intArrayOf(R.id.btnModeS, R.id.btnModeD, R.id.btnModeC)
    private val modeChars = charArrayOf('S', 'D', 'C')
    private val posIds = intArrayOf(R.id.btnPosTop, R.id.btnPosMid, R.id.btnPosBottom)

    private val pickVideo = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            videoUri = uri
            txtVideo.text = MediaInfo.displayName(this, uri)
            maybeAnalyze()
        }
    }

    private val pickSong = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            manualSongUri = uri
            updateSongSourceViews()
            maybeAnalyze()
        }
    }

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            prefs.libraryUri = uri.toString()
            manualSongUri = null
            updateSongSourceViews()
            countLibrarySongs()
            maybeAnalyze()
        }
    }

    private val pickScore = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scoreUri = uri
            txtScore.text = MediaInfo.displayName(this, uri)
            updateScoreInfo()
            updateEstimate()
        }
    }

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)
        bindViews()
        setupControls()
        updateSongSourceViews()
        countLibrarySongs()
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                ExportRunner.state.collect { render(it) }
            }
        }
    }

    override fun onDestroy() {
        titleAnimator?.cancel()
        super.onDestroy()
    }

    private fun bindViews() {
        txtVideo = findViewById(R.id.txtVideo)
        txtSong = findViewById(R.id.txtSong)
        btnSongFolder = findViewById(R.id.btnSongFolder)
        btnSongAuto = findViewById(R.id.btnSongAuto)
        txtScore = findViewById(R.id.txtScore)
        txtStatus = findViewById(R.id.txtStatus)
        progAnalyze = findViewById(R.id.progAnalyze)
        cards = listOf(
            findViewById(R.id.cardSync), findViewById(R.id.cardHook), findViewById(R.id.cardTitle),
            findViewById(R.id.cardScreen), findViewById(R.id.cardScore), findViewById(R.id.cardExport),
        )
        txtSyncInfo = findViewById(R.id.txtSyncInfo)
        txtNudge = findViewById(R.id.txtNudge)
        txtStart = findViewById(R.id.txtStart)
        txtEnd = findViewById(R.id.txtEnd)
        imgStart = findViewById(R.id.imgStart)
        imgEnd = findViewById(R.id.imgEnd)
        btnQuickTest = findViewById(R.id.btnQuickTest)
        switchHook = findViewById(R.id.switchHook)
        hookBody = findViewById(R.id.hookBody)
        txtHookLen = findViewById(R.id.txtHookLen)
        sliderHookLen = findViewById(R.id.sliderHookLen)
        imgHook = findViewById(R.id.imgHook)
        txtHook = findViewById(R.id.txtHook)
        switchTitle = findViewById(R.id.switchTitle)
        titleBody = findViewById(R.id.titleBody)
        groupTemplate = findViewById(R.id.groupTemplate)
        imgTitlePreview = findViewById(R.id.imgTitlePreview)
        editTitle = findViewById(R.id.editTitle)
        editArtist = findViewById(R.id.editArtist)
        editPlayer = findViewById(R.id.editPlayer)
        groupMode = findViewById(R.id.groupMode)
        txtLevel = findViewById(R.id.txtLevel)
        groupTitlePos = findViewById(R.id.groupTitlePos)
        cornerEditor = findViewById(R.id.cornerEditor)
        imgPreview = findViewById(R.id.imgPreview)
        sliderSize = findViewById(R.id.sliderSize)
        sliderY = findViewById(R.id.sliderY)
        groupAlign = findViewById(R.id.groupAlign)
        groupShape = findViewById(R.id.groupShape)
        txtScoreInfo = findViewById(R.id.txtScoreInfo)
        txtScoreSec = findViewById(R.id.txtScoreSec)
        sliderScoreSec = findViewById(R.id.sliderScoreSec)
        groupScoreBg = findViewById(R.id.groupScoreBg)
        groupRes = findViewById(R.id.groupRes)
        groupQuality = findViewById(R.id.groupQuality)
        txtEstimate = findViewById(R.id.txtEstimate)
        btnExport = findViewById(R.id.btnExport)
        progExport = findViewById(R.id.progExport)
        txtExportStatus = findViewById(R.id.txtExportStatus)
        rowDone = findViewById(R.id.rowDone)
        switchZoom = findViewById(R.id.switchZoom)
        zoomBody = findViewById(R.id.zoomBody)
        zoomControls = findViewById(R.id.zoomControls)
        btnHookPreview = findViewById(R.id.btnHookPreview)
        btnCopyError = findViewById(R.id.btnCopyError)
    }

    private fun setupControls() {
        findViewById<View>(R.id.btnVideo).setOnClickListener {
            pickVideo.launch(PickVisualMediaRequest.Builder().setMediaType(ActivityResultContracts.PickVisualMedia.VideoOnly).build())
        }
        btnSongFolder.setOnClickListener { pickFolder.launch(prefs.libraryUri?.let { Uri.parse(it) }) }
        findViewById<View>(R.id.btnSong).setOnClickListener { pickSong.launch(arrayOf("audio/*")) }
        btnSongAuto.setOnClickListener {
            manualSongUri = null
            updateSongSourceViews()
            maybeAnalyze()
        }
        findViewById<View>(R.id.btnScore).setOnClickListener {
            pickScore.launch(PickVisualMediaRequest.Builder().setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly).build())
        }

        // Audio nudge
        fun nudge(d: Int) {
            nudgeMs = (nudgeMs + d).coerceIn(-2000, 2000)
            updateNudge()
        }
        findViewById<View>(R.id.btnNudgeM50).setOnClickListener { nudge(-50) }
        findViewById<View>(R.id.btnNudgeM10).setOnClickListener { nudge(-10) }
        findViewById<View>(R.id.btnNudgeP10).setOnClickListener { nudge(10) }
        findViewById<View>(R.id.btnNudgeP50).setOnClickListener { nudge(50) }

        // Trim
        fun moveStart(d: Double) {
            val dur = videoInfo?.durationSec ?: return
            trimStart = (trimStart + d).coerceIn(0.0, max(0.0, min(dur, trimEnd) - 1.0))
            updateTrim()
        }
        fun moveEnd(d: Double) {
            val dur = videoInfo?.durationSec ?: return
            trimEnd = (trimEnd + d).coerceIn(min(dur, trimStart + 1.0), dur)
            updateTrim()
        }
        findViewById<View>(R.id.btnStartM1).setOnClickListener { moveStart(-1.0) }
        findViewById<View>(R.id.btnStartM01).setOnClickListener { moveStart(-0.1) }
        findViewById<View>(R.id.btnStartP01).setOnClickListener { moveStart(0.1) }
        findViewById<View>(R.id.btnStartP1).setOnClickListener { moveStart(1.0) }
        findViewById<View>(R.id.btnEndM1).setOnClickListener { moveEnd(-1.0) }
        findViewById<View>(R.id.btnEndM01).setOnClickListener { moveEnd(-0.1) }
        findViewById<View>(R.id.btnEndP01).setOnClickListener { moveEnd(0.1) }
        findViewById<View>(R.id.btnEndP1).setOnClickListener { moveEnd(1.0) }

        btnQuickTest.setOnClickListener { quickTest() }

        // Hook
        switchHook.isChecked = prefs.hookOn
        hookBody.visibility = if (prefs.hookOn) View.VISIBLE else View.GONE
        switchHook.setOnCheckedChangeListener { _, on ->
            prefs.hookOn = on
            hookBody.visibility = if (on) View.VISIBLE else View.GONE
            updateEstimate()
        }
        sliderHookLen.value = ((prefs.hookLen * 2).roundToInt() / 2f).coerceIn(2f, 6f)
        txtHookLen.text = "Length: ${fmtSec(sliderHookLen.value)}"
        sliderHookLen.addOnChangeListener { _, v, _ ->
            prefs.hookLen = v
            txtHookLen.text = "Length: ${fmtSec(v)}"
            autoHook()
            updateEstimate()
        }
        fun moveHook(d: Double) {
            val h = hookStart ?: return
            hookStart = h + d
            clampHook()
            updateHookViews()
        }
        findViewById<View>(R.id.btnHookM1).setOnClickListener { moveHook(-1.0) }
        findViewById<View>(R.id.btnHookM025).setOnClickListener { moveHook(-0.25) }
        findViewById<View>(R.id.btnHookP025).setOnClickListener { moveHook(0.25) }
        findViewById<View>(R.id.btnHookP1).setOnClickListener { moveHook(1.0) }
        findViewById<View>(R.id.btnHookAuto).setOnClickListener { pickHookCandidate(0) }
        findViewById<View>(R.id.btnHookNext).setOnClickListener {
            if (hookCandidates.isEmpty()) autoHook() else pickHookCandidate((hookIndex + 1) % hookCandidates.size)
        }
        btnHookPreview.setOnClickListener { previewHook() }

        // Title
        switchTitle.isChecked = prefs.titleOn
        titleBody.visibility = if (prefs.titleOn) View.VISIBLE else View.GONE
        switchTitle.setOnCheckedChangeListener { _, on ->
            prefs.titleOn = on
            titleBody.visibility = if (on) View.VISIBLE else View.GONE
        }
        groupTemplate.check(templateIds[prefs.template])
        groupTemplate.addOnButtonCheckedListener { _, id, isChecked ->
            if (isChecked) {
                prefs.template = templateIds.indexOf(id).coerceAtLeast(0)
                playTitle()
            }
        }
        groupTitlePos.check(posIds[prefs.titlePos])
        groupTitlePos.addOnButtonCheckedListener { _, id, isChecked ->
            if (isChecked) {
                prefs.titlePos = posIds.indexOf(id).coerceAtLeast(0)
                refreshTitlePreview()
            }
        }
        groupMode.check(modeIds[0])
        groupMode.addOnButtonCheckedListener { _, _, isChecked ->
            if (isChecked) {
                findViewById<View>(R.id.rowLevel).visibility = if (currentMode() == 'C') View.GONE else View.VISIBLE
                saveChart()
                refreshTitlePreview()
            }
        }
        findViewById<View>(R.id.btnLevelMinus).setOnClickListener { setLevel(level - 1) }
        findViewById<View>(R.id.btnLevelPlus).setOnClickListener { setLevel(level + 1) }
        editPlayer.setText(prefs.player)
        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (loadingTitleFields) return
                prefs.player = editPlayer.text?.toString()?.trim() ?: ""
                if (songName.isNotEmpty()) prefs.setTitle(songKey(), fieldText(editTitle), fieldText(editArtist))
                refreshTitlePreview()
            }
        }
        editTitle.addTextChangedListener(watcher)
        editArtist.addTextChangedListener(watcher)
        editPlayer.addTextChangedListener(watcher)
        findViewById<View>(R.id.btnPlayTitle).setOnClickListener { playTitle() }

        // Zoom on/off
        switchZoom.isChecked = prefs.zoomOn
        applyZoomVisibility()
        switchZoom.setOnCheckedChangeListener { _, on ->
            prefs.zoomOn = on
            applyZoomVisibility()
            refreshPreview(fast = false)
        }

        btnCopyError.setOnClickListener {
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("StepCut error", lastError))
            Toast.makeText(this, "Copied. Paste it to Claude.", Toast.LENGTH_SHORT).show()
        }

        // Screen corners
        cornerEditor.setCorners(prefs.corners)
        cornerEditor.onCornersChanged = { refreshPreview(fast = true) }
        cornerEditor.onEditFinished = {
            prefs.corners = cornerEditor.corners.copyOf()
            refreshPreview(fast = false)
        }
        findViewById<View>(R.id.btnResetCorners).setOnClickListener {
            cornerEditor.setCorners(PipGeometry.DEFAULT_CORNERS)
            prefs.corners = PipGeometry.DEFAULT_CORNERS.copyOf()
            refreshPreview(fast = false)
        }

        // PIP layout
        val pip = prefs.pip
        sliderSize.value = pip.widthPct.toFloat()
        sliderY.value = pip.yPct.toFloat()
        groupAlign.check(alignIds[pip.align])
        groupShape.check(shapeIds[pip.shape])
        sliderSize.addOnChangeListener { _, _, _ -> savePip() }
        sliderY.addOnChangeListener { _, _, _ -> savePip() }
        groupAlign.addOnButtonCheckedListener { _, _, isChecked -> if (isChecked) savePip() }
        groupShape.addOnButtonCheckedListener { _, _, isChecked -> if (isChecked) savePip() }

        // Score
        sliderScoreSec.value = ((prefs.scoreSec * 2).roundToInt() / 2f).coerceIn(1f, 10f)
        txtScoreSec.text = "Show for ${fmtSec(sliderScoreSec.value)}"
        sliderScoreSec.addOnChangeListener { _, v, _ ->
            prefs.scoreSec = v
            txtScoreSec.text = "Show for ${fmtSec(v)}"
            updateEstimate()
        }
        groupScoreBg.check(if (prefs.scoreBlur) R.id.btnBgBlur else R.id.btnBgBlack)
        groupScoreBg.addOnButtonCheckedListener { _, id, isChecked -> if (isChecked) prefs.scoreBlur = id == R.id.btnBgBlur }
        updateScoreInfo()

        // Export
        groupRes.check(resIds[prefs.resolution.coerceIn(0, 2)])
        groupQuality.check(qualityIds[prefs.quality.coerceIn(0, 2)])
        groupRes.addOnButtonCheckedListener { _, id, isChecked ->
            if (isChecked) {
                prefs.resolution = resIds.indexOf(id)
                updateEstimate()
            }
        }
        groupQuality.addOnButtonCheckedListener { _, id, isChecked ->
            if (isChecked) {
                prefs.quality = qualityIds.indexOf(id)
                updateEstimate()
            }
        }
        btnExport.setOnClickListener {
            if ((ExportRunner.state.value as? JobState.Running)?.kind == JobKind.EXPORT) ExportRunner.cancel() else export()
        }
        findViewById<View>(R.id.btnOpen).setOnClickListener {
            savedUri?.let { u ->
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            }
        }
        findViewById<View>(R.id.btnShare).setOnClickListener {
            savedUri?.let { u ->
                val send = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, u)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(Intent.createChooser(send, "Share video"))
            }
        }
    }

    // ---------------------------------------------------------------- song source

    private fun folderName(uri: String): String = try {
        DocumentsContract.getTreeDocumentId(Uri.parse(uri)).substringAfterLast(':').substringAfterLast('/').ifEmpty { "Song folder" }
    } catch (_: Exception) {
        "Song folder"
    }

    private fun updateSongSourceViews() {
        val lib = prefs.libraryUri
        btnSongFolder.text = if (lib == null) "Choose your song folder" else "Song folder: ${folderName(lib)}"
        val manual = manualSongUri
        if (manual != null) {
            txtSong.text = "Using: ${MediaInfo.displayName(this, manual)} (picked by hand)"
            btnSongAuto.visibility = if (lib != null) View.VISIBLE else View.GONE
        } else {
            btnSongAuto.visibility = View.GONE
            txtSong.text = if (lib == null) {
                "Pick the folder where you keep your clean songs. The app will work out which song you played."
            } else {
                "The song will be detected automatically."
            }
        }
    }

    private fun countLibrarySongs() {
        val lib = prefs.libraryUri ?: return
        if (manualSongUri != null) return
        lifecycleScope.launch {
            val n = withContext(Dispatchers.IO) {
                try { SongLibrary(this@MainActivity).scan(Uri.parse(lib)).size } catch (_: Exception) { -1 }
            }
            if (manualSongUri != null) return@launch
            txtSong.text = when {
                n < 0 -> "Can't open the song folder anymore. Please choose it again."
                n == 0 -> "No audio files found in that folder."
                else -> "$n songs in the folder. The song will be detected automatically."
            }
        }
    }

    // ---------------------------------------------------------------- analysis

    private fun maybeAnalyze() {
        if (videoUri != null && (manualSongUri != null || prefs.libraryUri != null)) analyze()
    }

    private class Analysis(
        val info: VideoInfo,
        val songUri: Uri,
        val songName: String,
        val songFp: Fingerprint,
        val sync: SyncResult,
        val meta: SongMeta,
        val frame: Bitmap,
        val note: String,
    )

    private fun analyze() {
        val v = videoUri ?: return
        val manual = manualSongUri
        val lib = prefs.libraryUri
        analyzeJob?.cancel()
        titleAnimator?.cancel()
        cards.forEach { it.visibility = View.GONE }
        progAnalyze.visibility = View.VISIBLE
        progAnalyze.setProgressCompat(0, false)
        txtStatus.text = "Reading the video…"
        askNotificationPermission()

        analyzeJob = lifecycleScope.launch {
            AppWork.begin(this@MainActivity, "Analysing your video…")
            try {
                val result = withContext(Dispatchers.Default) {
                    val ctx = this@MainActivity
                    val job = coroutineContext[Job]
                    val check: () -> Unit = { job?.ensureActive() }
                    val info = MediaInfo.readVideo(ctx, v)
                    status("Listening to the video's audio…", 0f)
                    val recFeatures = try {
                        AudioFeatureExtractor.extract(ctx, v, check) { p -> status("Listening to the video's audio…", p * 0.4f) }
                    } catch (e: NoAudioException) {
                        throw Exception("The video has no sound, so the song can't be matched to it.")
                    }
                    val rec = AudioSync.fingerprint(recFeatures)

                    val songUri: Uri
                    val songName: String
                    val songFp: Fingerprint
                    val sync: SyncResult
                    var note = ""
                    if (manual != null) {
                        status("Listening to the song…", 0.4f)
                        val f = AudioFeatureExtractor.extract(ctx, manual, check) { p -> status("Listening to the song…", 0.4f + p * 0.5f) }
                        songFp = AudioSync.fingerprint(f)
                        status("Matching the song to the video…", 0.92f)
                        sync = AudioSync.align(rec, songFp, info.durationSec)
                        songUri = manual
                        songName = MediaInfo.displayName(ctx, manual)
                    } else {
                        val library = SongLibrary(ctx)
                        status("Looking in your song folder…", 0.4f)
                        val entries = try {
                            library.scan(Uri.parse(lib!!))
                        } catch (e: Exception) {
                            throw Exception("Can't open your song folder. Please choose it again.")
                        }
                        if (entries.isEmpty()) throw Exception("Your song folder has no audio files.")
                        val r = library.recognize(rec, entries, info.durationSec, check) { msg, p -> status(msg, 0.4f + p * 0.55f) }
                        songUri = r.entry.uri
                        songName = r.entry.name
                        songFp = r.fingerprint
                        sync = r.sync
                        if (!r.sure) {
                            note = "\nNot completely sure about the song" + (r.runnerUp?.let { " (it could also be $it)" } ?: "") +
                                ". If it's wrong, tap \"Pick a song file instead\"."
                        }
                    }
                    check()
                    status("Reading the song's details…", 0.96f)
                    val meta = SongLibrary.readMeta(ctx, songUri, songName)
                    status("Grabbing a frame…", 0.98f)
                    val mid = (sync.songStartSec + sync.songEndSec) / 2
                    val frame = MediaInfo.frameAt(ctx, v, mid, 1080, info, exact = false)
                        ?: throw Exception("Couldn't read a frame from the video.")
                    Analysis(info, songUri, songName, songFp, sync, meta, frame, note)
                }
                applyAnalysis(result)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                txtStatus.text = "Something went wrong: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                progAnalyze.visibility = View.GONE
                AppWork.end(this@MainActivity)
            }
        }
    }

    private fun status(text: String, progress: Float) {
        AppWork.update(this, text, (progress * 100).roundToInt())
        runOnUiThread {
            txtStatus.text = text
            progAnalyze.setProgressCompat((progress * 100).roundToInt().coerceIn(0, 100), true)
        }
    }

    private fun applyAnalysis(a: Analysis) {
        videoInfo = a.info
        songUri = a.songUri
        songName = a.songName
        songFp = a.songFp
        songMeta = a.meta
        sync = a.sync
        nudgeMs = 0
        trimStart = a.sync.songStartSec
        trimEnd = a.sync.songEndSec
        frame = a.frame
        cornerEditor.bitmap = a.frame
        cornerEditor.setCorners(prefs.corners)

        val shownName = listOf(a.meta.title, a.meta.artist).filter { it.isNotBlank() }.joinToString(" – ").ifEmpty { a.songName }
        txtStatus.text = (if (manualSongUri == null) "Song: $shownName" else "Song: $shownName (picked by hand)") + a.note
        cards.forEach { it.visibility = View.VISIBLE }
        rowDone.visibility = View.GONE
        txtExportStatus.text = ""

        val c = a.sync.confidence
        val match = when {
            c >= 1.3 -> "Strong match"
            c >= 1.15 -> "Good match"
            else -> "Weak match. Use Quick test to check, and fine-tune if needed"
        }
        val where = if (a.sync.lagSec >= 0) {
            "The song starts at ${fmtTime(a.sync.lagSec)} in your video."
        } else {
            "Your recording started ${fmtSec(-a.sync.lagSec)} into the song."
        }
        txtSyncInfo.text = "$where\n$match (${"%.2f".format(Locale.US, c)}).\nSuggested clip: ${fmtTime(trimStart)} → ${fmtTime(trimEnd)}"

        loadTitleFields()
        autoHook()
        updateNudge()
        updateTrim()
        refreshPreview(fast = false)
        updateEstimate()
    }

    private fun updateNudge() {
        txtNudge.text = when {
            nudgeMs == 0 -> "0 ms"
            nudgeMs > 0 -> "+$nudgeMs ms\n(later)"
            else -> "$nudgeMs ms\n(earlier)"
        }
    }

    private fun updateTrim() {
        txtStart.text = fmtTime(trimStart)
        txtEnd.text = fmtTime(trimEnd)
        clampHook()
        updateHookViews()
        updateEstimate()
        val v = videoUri ?: return
        val info = videoInfo ?: return
        thumbJob?.cancel()
        thumbJob = lifecycleScope.launch {
            delay(250)
            val s = trimStart
            val e = trimEnd
            val (a, b) = withContext(Dispatchers.IO) {
                MediaInfo.frameAt(this@MainActivity, v, s, 240, info, exact = true) to
                    MediaInfo.frameAt(this@MainActivity, v, max(s, e - 0.05), 240, info, exact = true)
            }
            imgStart.setImageBitmap(a)
            imgEnd.setImageBitmap(b)
        }
    }

    // ---------------------------------------------------------------- hook

    private fun hookLen() = sliderHookLen.value.toDouble()

    /** Allowed hook starts: inside the clip and inside the song. */
    private fun hookRange(): ClosedFloatingPointRange<Double>? {
        val s = sync ?: return null
        val fp = songFp ?: return null
        val lag = s.lagSec + nudgeMs / 1000.0
        val lo = max(trimStart, lag + fp.startSec)
        val hi = min(trimEnd, lag + fp.startSec + fp.durationSec - 0.1) - hookLen()
        return if (hi > lo) lo..hi else null
    }

    private fun clampHook() {
        val h = hookStart ?: return
        val r = hookRange()
        hookStart = r?.let { h.coerceIn(it.start, it.endInclusive) }
    }

    private fun autoHook() {
        val s = sync ?: return
        val fp = songFp ?: return
        hookCandidates = HookFinder.candidates(fp, s.lagSec + nudgeMs / 1000.0, trimStart, trimEnd, hookLen(), 6)
        pickHookCandidate(0)
    }

    private fun pickHookCandidate(i: Int) {
        if (hookCandidates.isEmpty()) {
            hookStart = null
        } else {
            hookIndex = i.coerceIn(0, hookCandidates.size - 1)
            hookStart = hookCandidates[hookIndex]
        }
        clampHook()
        updateHookViews()
    }

    private fun updateHookViews() {
        val h = hookStart
        if (h == null) {
            txtHook.text = "No room for a hook"
            imgHook.setImageDrawable(null)
            return
        }
        val label = if (hookCandidates.size > 1) "  (pick ${hookIndex + 1}/${hookCandidates.size})" else ""
        txtHook.text = "${fmtTime(h)} → ${fmtTime(h + hookLen())}$label"
        val v = videoUri ?: return
        val info = videoInfo ?: return
        hookThumbJob?.cancel()
        hookThumbJob = lifecycleScope.launch {
            delay(250)
            val t = h + hookLen() / 2
            val bmp = withContext(Dispatchers.IO) { MediaInfo.frameAt(this@MainActivity, v, t, 240, info, exact = true) }
            imgHook.setImageBitmap(bmp)
        }
    }

    // ---------------------------------------------------------------- title

    private fun songKey() = songName.lowercase(Locale.US)

    private fun fieldText(e: EditText) = e.text?.toString()?.trim() ?: ""

    private fun currentMode(): Char = modeChars[modeIds.indexOf(groupMode.checkedButtonId).coerceAtLeast(0)]

    private fun loadTitleFields() {
        loadingTitleFields = true
        val meta = songMeta
        val saved = prefs.titleFor(songKey())
        editTitle.setText(saved?.first ?: meta?.title ?: "")
        editArtist.setText(saved?.second ?: meta?.artist ?: "")
        val (mode, lvl) = prefs.chartFor(songKey())
        groupMode.check(modeIds[modeChars.indexOf(mode).coerceAtLeast(0)])
        findViewById<View>(R.id.rowLevel).visibility = if (mode == 'C') View.GONE else View.VISIBLE
        level = lvl.coerceIn(1, 30)
        txtLevel.text = "Level $level"
        loadingTitleFields = false
    }

    private fun setLevel(l: Int) {
        level = l.coerceIn(1, 30)
        txtLevel.text = "Level $level"
        saveChart()
        refreshTitlePreview()
    }

    private fun saveChart() {
        if (loadingTitleFields || songName.isEmpty()) return
        prefs.setChart(songKey(), currentMode(), level)
    }

    private fun currentTitleSpec(): TitleSpec = TitleSpec(
        title = fieldText(editTitle).ifEmpty { songName.substringBeforeLast('.') },
        artist = fieldText(editArtist),
        mode = currentMode(),
        level = level,
        player = fieldText(editPlayer),
        template = templateIds.indexOf(groupTemplate.checkedButtonId).coerceAtLeast(0),
        position = posIds.indexOf(groupTitlePos.checkedButtonId).coerceAtLeast(0),
        accent = songMeta?.accent ?: SongLibrary.DEFAULT_ACCENT,
        art = songMeta?.art,
    )

    private fun titleFrame(base: Bitmap, t: Float, spec: TitleSpec): Bitmap {
        val out = base.copy(Bitmap.Config.ARGB_8888, true)
        titleRenderer.draw(Canvas(out), out.width.toFloat(), out.height.toFloat(), t, spec)
        return out
    }

    private fun refreshTitlePreview() {
        if (titleAnimator?.isRunning == true) return
        val base = previewBase ?: return
        imgTitlePreview.setImageBitmap(titleFrame(base, 1.8f, currentTitleSpec()))
    }

    private fun playTitle() {
        val base = previewBase ?: return
        titleAnimator?.cancel()
        val small = Bitmap.createScaledBitmap(base, 360, max(1, base.height * 360 / base.width), true)
        val spec = currentTitleSpec()
        titleAnimator = ValueAnimator.ofFloat(0f, TitleRenderer.END_TIME + 0.2f).apply {
            duration = ((TitleRenderer.END_TIME + 0.2f) * 1000).toLong()
            interpolator = LinearInterpolator()
            addUpdateListener { imgTitlePreview.setImageBitmap(titleFrame(small, it.animatedValue as Float, spec)) }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    imgTitlePreview.postDelayed({ refreshTitlePreview() }, 300)
                }
            })
            start()
        }
    }

    // ---------------------------------------------------------------- PIP preview

    private fun currentPip() = PipSettings(
        sliderSize.value.roundToInt(),
        sliderY.value.roundToInt(),
        alignIds.indexOf(groupAlign.checkedButtonId).coerceAtLeast(0),
        shapeIds.indexOf(groupShape.checkedButtonId).coerceAtLeast(0),
    )

    private fun savePip() {
        prefs.pip = currentPip()
        refreshPreview(fast = false)
    }

    private fun applyZoomVisibility() {
        val v = if (switchZoom.isChecked) View.VISIBLE else View.GONE
        zoomBody.visibility = v
        zoomControls.visibility = v
    }

    private fun pipRectFor(outW: Int, outH: Int): NRect? {
        if (!switchZoom.isChecked) return null
        val f = frame
        val pip = currentPip()
        val aspect = if (f != null) PipGeometry.pipAspect(pip, cornerEditor.corners, f.width, f.height) else 16f / 9f
        return PipGeometry.pipRect(outW, outH, pip, aspect)
    }

    private fun refreshPreview(fast: Boolean) {
        val f = frame ?: return
        val info = videoInfo ?: return
        val corners = cornerEditor.corners.copyOf()
        val rect = pipRectFor(info.width, info.height)
        previewJob?.cancel()
        previewJob = lifecycleScope.launch {
            if (fast) delay(60)
            val bmp = withContext(Dispatchers.Default) {
                PreviewRenderer.render(f, corners, rect, if (fast) 360 else 720)
            }
            imgPreview.setImageBitmap(bmp)
            if (!fast) {
                previewBase = bmp
                refreshTitlePreview()
            }
        }
    }

    // ---------------------------------------------------------------- score

    private fun updateScoreInfo() {
        txtScoreInfo.text = if (scoreUri == null) {
            "No score photo picked, so the video will end with the gameplay. Pick one in step 1 to add it."
        } else {
            "The score photo is shown after the gameplay."
        }
    }

    // ---------------------------------------------------------------- export

    private fun outputSize(info: VideoInfo, res: Int): Pair<Int, Int> {
        val short = min(info.width, info.height)
        val target = when (res) {
            0 -> 720
            1 -> 1080
            else -> short
        }.coerceAtMost(short)
        val scale = target.toDouble() / short
        var w = (info.width * scale).roundToInt()
        var h = (info.height * scale).roundToInt()
        val longSide = max(w, h)
        if (longSide > 3840) {
            val k = 3840.0 / longSide
            w = (w * k).roundToInt()
            h = (h * k).roundToInt()
        }
        return (w / 2 * 2) to (h / 2 * 2)
    }

    private fun bitrateFor(w: Int, h: Int, fps: Int, quality: Int): Int {
        val bpp = when (quality) {
            0 -> 0.08
            1 -> 0.13
            else -> 0.22
        }
        return (w.toDouble() * h * fps * bpp).toInt().coerceIn(1_000_000, 60_000_000)
    }

    private fun hookEnabled() = switchHook.isChecked && hookStart != null

    private fun clipSeconds(): Double {
        val score = if (scoreUri != null) sliderScoreSec.value.toDouble() else 0.0
        val hook = if (hookEnabled()) hookLen() else 0.0
        return (trimEnd - trimStart) + score + hook
    }

    private fun updateEstimate() {
        val info = videoInfo ?: return
        val res = resIds.indexOf(groupRes.checkedButtonId).coerceAtLeast(0)
        val q = qualityIds.indexOf(groupQuality.checkedButtonId).coerceAtLeast(0)
        val (w, h) = outputSize(info, res)
        val br = bitrateFor(w, h, info.fps, q)
        val secs = clipSeconds()
        val mb = (br + 192_000) * secs / 8 / 1_000_000
        txtEstimate.text = "Output: ${w}×$h, ${info.fps} fps · ${fmtTime(secs)} long · ≈ ${mb.roundToInt()} MB"
    }

    private fun buildParams(outW: Int, outH: Int, bitrate: Int, start: Double, end: Double, full: Boolean): ExportParams {
        val info = videoInfo!!
        val s = sync!!
        val title = if (full && switchTitle.isChecked) currentTitleSpec().takeIf { it.title.isNotBlank() } else null
        return ExportParams(
            videoUri = videoUri!!,
            songUri = songUri!!,
            trimStartSec = start,
            trimEndSec = end,
            lagSec = s.lagSec + nudgeMs / 1000.0,
            songDurSec = songFp?.durationSec ?: 0.0,
            corners = cornerEditor.corners.copyOf(),
            pipRect = pipRectFor(outW, outH),
            outW = outW,
            outH = outH,
            fps = info.fps,
            scoreImage = null, // rendered by ExportRunner from scoreUri
            scoreSec = if (full && scoreUri != null) sliderScoreSec.value.toDouble() else 0.0,
            videoBitrate = bitrate,
            hookStartSec = if (full && hookEnabled()) hookStart else null,
            hookLenSec = hookLen(),
            title = title,
            titleRenderer = if (title != null) titleRenderer else null,
        )
    }

    private fun safeName(s: String) = s.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').take(40)

    private fun ready(): Boolean {
        if (videoInfo == null || sync == null || songUri == null) return false
        if (ExportRunner.isRunning) {
            Toast.makeText(this, "Something is already being made. Wait for it to finish.", Toast.LENGTH_SHORT).show()
            return false
        }
        askNotificationPermission()
        return true
    }

    private fun export() {
        if (!ready()) return
        titleAnimator?.cancel()
        val info = videoInfo!!
        val res = resIds.indexOf(groupRes.checkedButtonId).coerceAtLeast(0)
        val q = qualityIds.indexOf(groupQuality.checkedButtonId).coerceAtLeast(0)
        val (outW, outH) = outputSize(info, res)
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val titlePart = safeName(fieldText(editTitle)).let { if (it.isEmpty()) "" else "${it}_" }
        val params = buildParams(outW, outH, bitrateFor(outW, outH, info.fps, q), trimStart, trimEnd, full = true)
        ExportRunner.start(this, JobKind.EXPORT, params, scoreUri, prefs.scoreBlur, "StepCut_$titlePart$stamp.mp4")
    }

    private fun quickTest() {
        if (!ready()) return
        val (outW, outH) = outputSize(videoInfo!!, 0)
        val mid = (trimStart + trimEnd) / 2
        val s = max(trimStart, mid - 5)
        val e = min(trimEnd, s + 10)
        ExportRunner.start(this, JobKind.QUICK_TEST, buildParams(outW, outH, 4_000_000, s, e, full = false), null, false, null)
    }

    /** Short 720p clip: the hook, the flash, and the first 1.5 s of the song. */
    private fun previewHook() {
        if (hookStart == null) {
            Toast.makeText(this, "There's no hook to preview (the clip may be too short).", Toast.LENGTH_LONG).show()
            return
        }
        if (!ready()) return
        val (outW, outH) = outputSize(videoInfo!!, 0)
        val base = buildParams(outW, outH, 4_000_000, trimStart, min(trimEnd, trimStart + 1.5), full = false)
        val params = base.copy(hookStartSec = hookStart)
        ExportRunner.start(this, JobKind.HOOK_PREVIEW, params, null, false, null)
    }

    /** Shows whatever the background export is doing, and its result when it finishes. */
    private fun render(state: JobState) {
        val busy = state is JobState.Running
        setBusy(busy)
        btnQuickTest.text = "Quick test (10 s clip)"
        btnHookPreview.text = "▶  Preview hook"
        btnExport.text = "Export video"
        when (state) {
            is JobState.Idle -> {
                progExport.visibility = View.GONE
            }
            is JobState.Running -> {
                btnCopyError.visibility = View.GONE
                when (state.kind) {
                    JobKind.EXPORT -> {
                        rowDone.visibility = View.GONE
                        btnExport.text = "Cancel"
                        progExport.visibility = View.VISIBLE
                        if (state.percent >= 0) progExport.setProgressCompat(state.percent, true)
                        txtExportStatus.text = state.text + "\nYou can leave the app; it keeps going in the background."
                    }
                    JobKind.QUICK_TEST -> btnQuickTest.text = state.text
                    JobKind.HOOK_PREVIEW -> btnHookPreview.text = state.text
                }
            }
            is JobState.Done -> {
                progExport.visibility = View.GONE
                when (state.kind) {
                    JobKind.EXPORT -> {
                        savedUri = state.uri
                        txtExportStatus.text = "Saved to Movies/StepCut as ${state.name}"
                        rowDone.visibility = View.VISIBLE
                    }
                    JobKind.QUICK_TEST -> state.file?.let { showVideoDialog(it) }
                    JobKind.HOOK_PREVIEW -> state.file?.let {
                        showVideoDialog(it, "Hook preview", "Happy with it? If not, tap \"Try another\" or move it with the buttons.")
                    }
                }
                ExportRunner.acknowledge()
            }
            is JobState.Failed -> {
                progExport.visibility = View.GONE
                val what = when (state.kind) {
                    JobKind.EXPORT -> "Export"
                    JobKind.QUICK_TEST -> "Quick test"
                    JobKind.HOOK_PREVIEW -> "Hook preview"
                }
                if (state.details.isEmpty()) {
                    txtExportStatus.text = "$what cancelled."
                } else {
                    lastError = state.details
                    txtExportStatus.text = "$what failed:\n${state.message}"
                    btnCopyError.visibility = View.VISIBLE
                    AlertDialog.Builder(this)
                        .setTitle("$what failed")
                        .setMessage(state.message)
                        .setPositiveButton("Copy details") { _, _ -> btnCopyError.performClick() }
                        .setNegativeButton("Close", null)
                        .show()
                }
                ExportRunner.acknowledge()
            }
        }
    }

    private fun showVideoDialog(
        file: File,
        title: String = "Quick test",
        message: String = "Does the music line up with your steps? If not, use the fine-tune buttons and test again.",
    ) {
        val videoView = VideoView(this)
        val container = FrameLayout(this)
        container.setPadding(0, 24, 0, 0)
        container.addView(
            videoView,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, android.view.Gravity.CENTER),
        )
        val controller = MediaController(this)
        controller.setAnchorView(videoView)
        videoView.setMediaController(controller)
        videoView.setVideoPath(file.absolutePath)
        videoView.setOnPreparedListener { it.isLooping = true; videoView.start() }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setView(container)
            .setPositiveButton("Close") { d, _ -> d.dismiss() }
            .setOnDismissListener { videoView.stopPlayback() }
            .show()
    }

    private fun setBusy(busy: Boolean) {
        btnQuickTest.isEnabled = !busy
        btnHookPreview.isEnabled = !busy
        findViewById<View>(R.id.btnVideo).isEnabled = !busy
        findViewById<View>(R.id.btnSong).isEnabled = !busy
        btnSongFolder.isEnabled = !busy
        btnSongAuto.isEnabled = !busy
        findViewById<View>(R.id.btnScore).isEnabled = !busy
        // The export button doubles as Cancel while exporting.
        btnExport.isEnabled = !busy || (ExportRunner.state.value as? JobState.Running)?.kind == JobKind.EXPORT
    }

    private var askedNotifications = false

    private fun askNotificationPermission() {
        if (askedNotifications || Build.VERSION.SDK_INT < 33) return
        askedNotifications = true
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // ---------------------------------------------------------------- formatting

    private fun fmtTime(sec: Double): String {
        val s = max(0.0, sec)
        val m = (s / 60).toInt()
        val rest = s - m * 60
        return String.format(Locale.US, "%d:%04.1f", m, rest)
    }

    private fun fmtSec(sec: Float): String = fmtSec(sec.toDouble())

    private fun fmtSec(sec: Double): String =
        if (abs(sec - sec.roundToInt()) < 1e-6) "${sec.roundToInt()} s" else String.format(Locale.US, "%.1f s", sec)
}
