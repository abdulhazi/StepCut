package com.steve.stepcut

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class JobKind { EXPORT, QUICK_TEST, HOOK_PREVIEW }

sealed class JobState {
    object Idle : JobState()
    data class Running(val kind: JobKind, val text: String, val percent: Int) : JobState()
    data class Done(val kind: JobKind, val file: File?, val uri: Uri?, val name: String?) : JobState()
    data class Failed(val kind: JobKind, val message: String, val details: String) : JobState()
}

/**
 * Runs exports outside the screen's lifetime, so they keep going (with a notification) while you
 * use other apps. The screen just watches [state].
 */
object ExportRunner {
    private val _state = MutableStateFlow<JobState>(JobState.Idle)
    val state: StateFlow<JobState> = _state
    private var job: Job? = null

    val isRunning: Boolean get() = job?.isActive == true

    /** The screen has shown a Done/Failed result. */
    fun acknowledge() {
        if (_state.value is JobState.Done || _state.value is JobState.Failed) _state.value = JobState.Idle
    }

    fun cancel() {
        job?.cancel()
    }

    private fun label(kind: JobKind) = when (kind) {
        JobKind.EXPORT -> "Exporting your video…"
        JobKind.QUICK_TEST -> "Making the quick test…"
        JobKind.HOOK_PREVIEW -> "Making the hook preview…"
    }

    fun start(
        ctx: Context,
        kind: JobKind,
        params: ExportParams,
        scoreUri: Uri?,
        scoreBlur: Boolean,
        galleryName: String?,
    ) {
        if (isRunning) return
        val app = ctx.applicationContext
        AppWork.begin(app, label(kind))
        fun update(text: String, percent: Int) {
            _state.value = JobState.Running(kind, text, percent)
            AppWork.update(app, text, percent)
        }
        update("Preparing…", -1)

        job = AppWork.scope.launch {
            val stamp = System.nanoTime()
            val outFile = File(app.cacheDir, if (kind == JobKind.EXPORT) "stepcut_$stamp.mp4" else "preview_${kind.name.lowercase()}.mp4")
            var scoreFile: File? = null
            val wav = File(app.cacheDir, "soundtrack_$stamp.wav")
            try {
                if (scoreUri != null) {
                    update("Preparing the score photo…", -1)
                    scoreFile = withContext(Dispatchers.IO) {
                        File(app.cacheDir, "score_$stamp.jpg").also {
                            ScoreImageRenderer.render(app, scoreUri, params.outW, params.outH, scoreBlur, it)
                        }
                    }
                }
                val p = params.copy(scoreImage = scoreFile, scoreSec = if (scoreFile != null) params.scoreSec else 0.0)

                update("Building the soundtrack…", -1)
                withContext(Dispatchers.Default) {
                    val j = coroutineContext[Job]
                    AudioMixdown.render(app, p.songUri, ExportEngine.soundtrackPieces(p), wav) { j?.ensureActive() }
                }

                update("${label(kind).removeSuffix("…")} 0%", 0)
                runTransformer(app, p.copy(soundtrack = wav), outFile) { pct ->
                    update("${label(kind).removeSuffix("…")} $pct%", pct)
                }

                if (kind == JobKind.EXPORT) {
                    update("Saving to your gallery…", -1)
                    val name = galleryName ?: "StepCut_$stamp.mp4"
                    val uri = withContext(Dispatchers.IO) { MediaInfo.saveToGallery(app, outFile, name) }
                    _state.value = JobState.Done(kind, null, uri, name)
                    AppWork.notifyDone(app, "Video saved", "$name is in Movies/StepCut. Tap to watch.", uri)
                } else {
                    _state.value = JobState.Done(kind, outFile, null, null)
                    val what = if (kind == JobKind.HOOK_PREVIEW) "Hook preview" else "Quick test"
                    AppWork.notifyDone(app, "$what ready", "Tap to watch it in StepCut.", null)
                }
            } catch (e: CancellationException) {
                _state.value = JobState.Failed(kind, "Cancelled.", "")
            } catch (e: Exception) {
                val details = "StepCut ${BuildConfigInfo.VERSION} (${kind.name.lowercase()})\n" + (e.message ?: ExportEngine.describe(e))
                _state.value = JobState.Failed(kind, e.message ?: e.javaClass.simpleName, details)
                AppWork.notifyDone(app, "StepCut couldn't finish", "Open the app to see what went wrong.", null)
            } finally {
                withContext(NonCancellable + Dispatchers.IO) {
                    wav.delete()
                    scoreFile?.delete()
                    if (kind == JobKind.EXPORT) outFile.delete()
                }
                AppWork.end(app)
            }
        }
    }

    private suspend fun runTransformer(app: Context, params: ExportParams, outFile: File, onProgress: (Int) -> Unit): File =
        suspendCancellableCoroutine { cont ->
            val engine = ExportEngine(app)
            cont.invokeOnCancellation { engine.cancel() }
            try {
                engine.start(params, outFile, onProgress) { result ->
                    if (cont.isActive) result.fold({ cont.resume(it) }, { cont.resumeWithException(it) })
                }
            } catch (e: Exception) {
                if (cont.isActive) cont.resumeWithException(e)
            }
        }
}
