package com.steve.stepcut

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Log band energies of an audio stream, resampled onto a fixed 100 Hz grid.
 *
 * bands[k] holds the energies at time startSec + k / GRID_HZ (stream time, seconds).
 */
class AudioFeatures(
    val bands: Array<FloatArray>,
    val startSec: Double,
    val durationSec: Double,
) {
    companion object {
        const val GRID_HZ = 100.0
        const val NBANDS = 24
    }
}

class NoAudioException(message: String) : Exception(message)

object AudioFeatureExtractor {

    /** Decodes the first audio track of [uri] and computes its band features. Blocking. */
    fun extract(
        context: Context,
        uri: Uri,
        checkCancelled: () -> Unit,
        progress: (Float) -> Unit,
    ): AudioFeatures {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)
            var track = -1
            for (i in 0 until extractor.trackCount) {
                val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    track = i
                    break
                }
            }
            if (track < 0) throw NoAudioException("This file has no audio track.")
            extractor.selectTrack(track)
            val inFormat = extractor.getTrackFormat(track)
            val mime = inFormat.getString(MediaFormat.KEY_MIME)!!
            val durUs = if (inFormat.containsKey(MediaFormat.KEY_DURATION)) inFormat.getLong(MediaFormat.KEY_DURATION) else 0L
            var channels = if (inFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) inFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            var sampleRate = if (inFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) inFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var pcmEncoding = AudioFormat.ENCODING_PCM_16BIT

            val c = MediaCodec.createDecoderByType(mime)
            codec = c
            c.configure(inFormat, null, null, 0)
            c.start()

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var analyzer: BandAnalyzer? = null
            var firstPtsUs = -1L
            var monoSamples = 0L
            var lastProgressUs = 0L

            while (!outputDone) {
                checkCancelled()
                if (!inputDone) {
                    val inIdx = c.dequeueInputBuffer(5_000)
                    if (inIdx >= 0) {
                        val buf = c.getInputBuffer(inIdx)!!
                        val size = extractor.readSampleData(buf, 0)
                        if (size < 0) {
                            c.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            c.queueInputBuffer(inIdx, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outIdx = c.dequeueOutputBuffer(info, 5_000)
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = c.outputFormat
                    if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (f.containsKey(MediaFormat.KEY_PCM_ENCODING)) pcmEncoding = f.getInteger(MediaFormat.KEY_PCM_ENCODING)
                } else if (outIdx >= 0) {
                    if (info.size > 0) {
                        val out = c.getOutputBuffer(outIdx)!!
                        out.position(info.offset)
                        out.limit(info.offset + info.size)
                        if (firstPtsUs < 0) firstPtsUs = info.presentationTimeUs
                        val a = analyzer ?: BandAnalyzer(sampleRate).also { analyzer = it }
                        val bb = out.slice().order(ByteOrder.nativeOrder())
                        val ch = max(1, channels)
                        if (pcmEncoding == AudioFormat.ENCODING_PCM_FLOAT) {
                            val fb = bb.asFloatBuffer()
                            val frames = fb.remaining() / ch
                            for (i in 0 until frames) {
                                var s = 0f
                                for (k in 0 until ch) s += fb.get()
                                a.push(s / ch)
                            }
                            monoSamples += frames
                        } else {
                            val sb = bb.asShortBuffer()
                            val frames = sb.remaining() / ch
                            val scale = 1f / (32768f * ch)
                            for (i in 0 until frames) {
                                var s = 0
                                for (k in 0 until ch) s += sb.get().toInt()
                                a.push(s * scale)
                            }
                            monoSamples += frames
                        }
                        if (durUs > 0 && info.presentationTimeUs - lastProgressUs > 400_000) {
                            lastProgressUs = info.presentationTimeUs
                            progress((info.presentationTimeUs.toFloat() / durUs).coerceIn(0f, 1f))
                        }
                    }
                    c.releaseOutputBuffer(outIdx, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                }
            }

            val a = analyzer ?: throw NoAudioException("The audio track is empty.")
            val grid = a.toGrid()
            if (grid.size < 300) throw NoAudioException("The audio is too short (needs at least a few seconds).")
            progress(1f)
            return AudioFeatures(grid, max(0L, firstPtsUs) / 1e6, monoSamples.toDouble() / sampleRate)
        } finally {
            try {
                codec?.stop()
            } catch (_: Exception) {
            }
            try {
                codec?.release()
            } catch (_: Exception) {
            }
            extractor.release()
        }
    }
}

/** Streaming STFT band-energy analyser. */
private class BandAnalyzer(inputRate: Int) {
    private val decim = max(1, inputRate / 16000)
    private val sr = inputRate.toDouble() / decim
    private val hop = max(1, (sr * 0.01).roundToInt())
    private val win: Int = run {
        var w = 2
        while (w < sr * 0.04) w = w shl 1
        w
    }
    private val hann = FloatArray(win) { (0.5 - 0.5 * cos(2.0 * PI * it / (win - 1))).toFloat() }
    private val buf = FloatArray(win)
    private var filled = 0
    private var accSum = 0f
    private var accCount = 0
    private val re = DoubleArray(win)
    private val im = DoubleArray(win)
    private val binLo = IntArray(AudioFeatures.NBANDS)
    private val binHi = IntArray(AudioFeatures.NBANDS)
    private val frames = ArrayList<FloatArray>()

    init {
        val fMin = 100.0
        val fMax = 7000.0
        val nb = AudioFeatures.NBANDS
        for (b in 0 until nb) {
            val lo = fMin * (fMax / fMin).pow(b.toDouble() / nb)
            val hi = fMin * (fMax / fMin).pow((b + 1).toDouble() / nb)
            val bl = (lo * win / sr).roundToInt().coerceIn(1, win / 2)
            val bh = (hi * win / sr).roundToInt().coerceIn(1, win / 2)
            binLo[b] = bl
            binHi[b] = max(bh, bl + 1)
        }
    }

    fun push(sample: Float) {
        accSum += sample
        accCount++
        if (accCount == decim) {
            addSample(accSum / decim)
            accSum = 0f
            accCount = 0
        }
    }

    private fun addSample(s: Float) {
        buf[filled++] = s
        if (filled == win) {
            processFrame()
            System.arraycopy(buf, hop, buf, 0, win - hop)
            filled = win - hop
        }
    }

    private fun processFrame() {
        for (i in 0 until win) {
            re[i] = (buf[i] * hann[i]).toDouble()
            im[i] = 0.0
        }
        Fft.transform(re, im)
        val out = FloatArray(AudioFeatures.NBANDS)
        for (b in 0 until AudioFeatures.NBANDS) {
            var e = 0.0
            for (k in binLo[b] until binHi[b]) e += re[k] * re[k] + im[k] * im[k]
            out[b] = ln(e + 1e-6).toFloat()
        }
        frames.add(out)
    }

    /** Interpolates the analysis frames onto a 100 Hz grid starting at the first sample. */
    fun toGrid(): Array<FloatArray> {
        if (frames.isEmpty()) return emptyArray()
        val lastTime = ((frames.size - 1) * hop + win / 2) / sr
        val n = (lastTime * AudioFeatures.GRID_HZ).toInt() + 1
        val nb = AudioFeatures.NBANDS
        return Array(n) { k ->
            val t = k / AudioFeatures.GRID_HZ
            val pos = ((t * sr - win / 2.0) / hop).coerceIn(0.0, (frames.size - 1).toDouble())
            val i0 = floor(pos).toInt()
            val i1 = minOf(i0 + 1, frames.size - 1)
            val frac = (pos - i0).toFloat()
            val a = frames[i0]
            val b = frames[i1]
            FloatArray(nb) { a[it] + (b[it] - a[it]) * frac }
        }
    }
}
