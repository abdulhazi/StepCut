package com.steve.stepcut

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import kotlin.math.roundToInt

/** CPU version of the PIP effect, for the on-screen preview. */
object PreviewRenderer {
    fun render(frame: Bitmap, corners: FloatArray, rect: NRect?, width: Int = 540): Bitmap {
        val h = (width.toFloat() * frame.height / frame.width).roundToInt().coerceAtLeast(1)
        val out = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        canvas.drawBitmap(frame, null, Rect(0, 0, width, h), paint)
        if (rect == null) return out

        val fw = frame.width.toFloat()
        val fh = frame.height.toFloat()
        val src = floatArrayOf(
            corners[0] * fw, corners[1] * fh,
            corners[2] * fw, corners[3] * fh,
            corners[4] * fw, corners[5] * fh,
            corners[6] * fw, corners[7] * fh,
        )
        val l = rect.left * width
        val t = rect.top * h
        val r = rect.right * width
        val b = rect.bottom * h
        val dst = floatArrayOf(l, t, r, t, r, b, l, b)
        val m = Matrix()
        if (m.setPolyToPoly(src, 0, dst, 0, 4)) {
            canvas.save()
            canvas.clipRect(l, t, r, b)
            canvas.drawBitmap(frame, m, paint)
            canvas.restore()
        }
        return out
    }
}
