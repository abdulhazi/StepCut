package com.steve.stepcut

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.widget.Magnifier
import kotlin.math.hypot
import kotlin.math.min

/**
 * Shows a video frame with 4 draggable corner handles (TL, TR, BR, BL) for marking the game
 * screen. Dragging inside the shape moves all corners. A magnifier helps place corners exactly.
 */
class CornerEditorView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    var bitmap: Bitmap? = null
        set(value) {
            field = value
            requestLayout()
            invalidate()
        }

    /** Normalised corners, y down: TL x,y, TR x,y, BR x,y, BL x,y. */
    val corners = FloatArray(8)

    var onCornersChanged: (() -> Unit)? = null
    var onEditFinished: (() -> Unit)? = null

    private val density = resources.displayMetrics.density
    private val dst = RectF()
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dimPaint = Paint().apply { color = Color.argb(140, 0, 0, 0) }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(53, 224, 192)
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
    }
    private val handleFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(90, 53, 224, 192) }
    private val handleStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
    }
    private val path = Path()
    private val magnifier: Magnifier? = try {
        Magnifier.Builder(this).setInitialZoom(2.5f).setSize((110 * density).toInt(), (110 * density).toInt()).build()
    } catch (_: Exception) {
        null
    }

    private var active = -1 // 0..3 corner, 4 = move all
    private var lastX = 0f
    private var lastY = 0f

    fun setCorners(c: FloatArray) {
        System.arraycopy(c, 0, corners, 0, 8)
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val b = bitmap
        val maxH = (resources.displayMetrics.heightPixels * 0.72f).toInt()
        val h = if (b != null && b.width > 0) min(maxH, (w.toLong() * b.height / b.width).toInt()) else (w * 9 / 16)
        setMeasuredDimension(w, h)
    }

    private fun updateDst() {
        val b = bitmap ?: return
        val scale = min(width.toFloat() / b.width, height.toFloat() / b.height)
        val dw = b.width * scale
        val dh = b.height * scale
        dst.set((width - dw) / 2f, (height - dh) / 2f, (width + dw) / 2f, (height + dh) / 2f)
    }

    private fun px(i: Int) = dst.left + corners[2 * i] * dst.width()
    private fun py(i: Int) = dst.top + corners[2 * i + 1] * dst.height()

    override fun onDraw(canvas: Canvas) {
        val b = bitmap ?: return
        updateDst()
        canvas.drawBitmap(b, null, dst, bmpPaint)
        path.reset()
        path.moveTo(px(0), py(0))
        for (i in 1..3) path.lineTo(px(i), py(i))
        path.close()
        canvas.save()
        canvas.clipOutPath(path)
        canvas.drawRect(dst, dimPaint)
        canvas.restore()
        canvas.drawPath(path, linePaint)
        val r = 13f * density
        for (i in 0..3) {
            canvas.drawCircle(px(i), py(i), r, handleFill)
            canvas.drawCircle(px(i), py(i), r, handleStroke)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (bitmap == null) return false
        val x = event.x
        val y = event.y
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                updateDst()
                var best = -1
                var bestD = 40f * density
                for (i in 0..3) {
                    val d = hypot(x - px(i), y - py(i))
                    if (d < bestD) {
                        bestD = d
                        best = i
                    }
                }
                active = if (best >= 0) best else if (insideQuad(x, y)) 4 else -1
                if (active < 0) return false
                parent?.requestDisallowInterceptTouchEvent(true)
                lastX = x
                lastY = y
                if (active < 4) magnifier?.show(px(active), py(active))
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (active < 0) return false
                val dx = (x - lastX) / dst.width()
                val dy = (y - lastY) / dst.height()
                lastX = x
                lastY = y
                if (active < 4) {
                    corners[2 * active] = (corners[2 * active] + dx).coerceIn(0f, 1f)
                    corners[2 * active + 1] = (corners[2 * active + 1] + dy).coerceIn(0f, 1f)
                    magnifier?.show(px(active), py(active))
                } else {
                    var mdx = dx
                    var mdy = dy
                    for (i in 0..3) {
                        mdx = mdx.coerceIn(-corners[2 * i], 1f - corners[2 * i])
                        mdy = mdy.coerceIn(-corners[2 * i + 1], 1f - corners[2 * i + 1])
                    }
                    for (i in 0..3) {
                        corners[2 * i] += mdx
                        corners[2 * i + 1] += mdy
                    }
                }
                invalidate()
                onCornersChanged?.invoke()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (active < 0) return false
                active = -1
                magnifier?.dismiss()
                parent?.requestDisallowInterceptTouchEvent(false)
                onEditFinished?.invoke()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun insideQuad(x: Float, y: Float): Boolean {
        var inside = false
        var j = 3
        for (i in 0..3) {
            val xi = px(i); val yi = py(i); val xj = px(j); val yj = py(j)
            if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) inside = !inside
            j = i
        }
        return inside
    }
}
