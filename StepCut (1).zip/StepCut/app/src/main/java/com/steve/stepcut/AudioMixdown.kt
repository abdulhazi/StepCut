package com.steve.stepcut

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong

/**
 * Builds the finished soundtrack as one WAV file: the song pieces lined up exactly with the video
 * pieces (hook, main clip), silence where there is no song, short fades so cuts don't click.
 *
 * Doing this ourselves (instead of clipping the MP3 inside the exporter) keeps the timing
 * sample-accurate and uses the same decoder that was used for syncing.
 */
object AudioMixdown {

    /** One part of the output timeline. songFromSec < 0 or past the song's end gives silence. */
    class Piece(val songFromSec: Double, val lenSec: Double, val fadeInSec: Double, val fadeOutSec: Double)

    private class Pcm(val data: ShortArray, val channels: Int, val sampleRate: Int, val startSec: Double) {
        val frames: Int get() = data.size / channels
    }

    fun render(context: Context, songUri: Uri, pieces: List<Piece>, outFile: File, checkCancelled: () -> Unit) {
        val pcm = decode(context, songUri, checkCancelled)
        val sr = pcm.sampleRate
        val outCh = 2
        var totalFrames = 0L
        val pieceFrames = pieces.map { (it.lenSec * sr).roundToLong().coerceAtLeast(0L) }
        for (n in pieceFrames) totalFrames += n
        val dataBytes = totalFrames * outCh * 2

        BufferedOutputStream(FileOutputStream(outFile), 1 shl 16).use { out ->
            writeWavHeader(out, sr, outCh, dataBytes)
            val buf = ByteBuffer.allocate(4096 * outCh * 2).order(ByteOrder.LITTLE_ENDIAN)
            pieces.forEachIndexed { pi, p ->
                checkCancelled()
                val n = pieceFrames[pi]
                // Song frame index of the first output frame in this piece.
                val songStart = ((p.songFromSec - pcm.startSec) * sr).roundToLong()
                val fadeIn = (p.fadeInSec * sr).toLong()
                val fadeOut = (p.fadeOutSec * sr).toLong()
                for (i in 0 until n) {
                    val si = songStart + i
                    var l = 0
                    var r = 0
                    if (si >= 0 && si < pcm.frames) {
                        val base = (si * pcm.channels).toInt()
                        l = pcm.data[base].toInt()
                        r = if (pcm.channels > 1) pcm.data[base + 1].toInt() else l
                    }
                    var g = 1.0
                    if (fadeIn > 0 && i < fadeIn) g = min(g, i.toDouble() / fadeIn)
                    if (fadeOut > 0 && i >= n - fadeOut) g = min(g, (n - 1 - i).toDouble() / fadeOut)
                    if (g < 1.0) {
                        l = (l * g).toInt()
                        r = (r * g).toInt()
                    }
                    buf.putShort(l.toShort())
                    buf.putShort(r.toShort())
                    if (!buf.hasRemaining()) {
                        out.write(buf.array(), 0, buf.position())
                        buf.clear()
                    }
                }
            }
            if (buf.position() > 0) out.write(buf.array(), 0, buf.position())
        }
    }

    private fun writeWavHeader(out: BufferedOutputStream, sr: Int, ch: Int, dataBytes: Long) {
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray())
        h.putInt((36 + dataBytes).coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
        h.put("WAVE".toByteArray())
        h.put("fmt ".toByteArray())
        h.putInt(16)
        h.putShort(1) // PCM
        h.putShort(ch.toShort())
        h.putInt(sr)
        h.putInt(sr * ch * 2)
        h.putShort((ch * 2).toShort())
        h.putShort(16)
        h.put("data".toByteArray())
        h.putInt(dataBytes.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
        out.write(h.array())
    }

    /** Decodes the whole song to interleaved 16-bit PCM (same decoder as the sync step). */
    private fun decode(context: Context, uri: Uri, checkCancelled: () -> Unit): Pcm {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)
            var track = -1
            for (i in 0 until extractor.trackCount) {
                val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    track = i
                    break
                }
            }
            if (track < 0) throw NoAudioException("The song file has no audio.")
            extractor.selectTrack(track)
            val inFormat = extractor.getTrackFormat(track)
            var channels = if (inFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) inFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            var sampleRate = if (inFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) inFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var pcmEncoding = AudioFormat.ENCODING_PCM_16BIT
            val c = MediaCodec.createDecoderByType(inFormat.getString(MediaFormat.KEY_MIME)!!)
            codec = c
            c.configure(inFormat, null, null, 0)
            c.start()

            var data = ShortArray(1 shl 20)
            var size = 0
            fun ensure(extra: Int) {
                if (size + extra > data.size) data = data.copyOf(max(data.size * 2, size + extra))
            }

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var firstPtsUs = -1L
            var outChannels = -1
            while (!outputDone) {
                checkCancelled()
                if (!inputDone) {
                    val inIdx = c.dequeueInputBuffer(5_000)
                    if (inIdx >= 0) {
                        val b = c.getInputBuffer(inIdx)!!
                        val n = extractor.readSampleData(b, 0)
                        if (n < 0) {
                            c.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            c.queueInputBuffer(inIdx, 0, n, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIdx = c.dequeueOutputBuffer(info, 5_000)
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = c.outputFormat
                    if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (f.containsKey(MediaFormat.KEY_PCM_ENCODING)) pcmEncoding = f.getInteger(MediaFormat.KEY_PCM_ENCODING)
                } else if (outIdx >= 0) {
                    if (info.size > 0) {
                        if (firstPtsUs < 0) firstPtsUs = info.presentationTimeUs
                        if (outChannels < 0) outChannels = max(1, min(2, channels))
                        val ch = max(1, channels)
                        val out = c.getOutputBuffer(outIdx)!!
                        out.position(info.offset)
                        out.limit(info.offset + info.size)
                        val bb = out.slice().order(ByteOrder.nativeOrder())
                        if (pcmEncoding == AudioFormat.ENCODING_PCM_FLOAT) {
                            val fb = bb.asFloatBuffer()
                            val frames = fb.remaining() / ch
                            ensure(frames * outChannels)
                            for (i in 0 until frames) {
                                for (k in 0 until ch) {
                                    val v = (fb.get() * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                                    if (k < outChannels) data[size++] = v
                                }
                            }
                        } else {
                            val sb = bb.asShortBuffer()
                            val frames = sb.remaining() / ch
                            ensure(frames * outChannels)
                            for (i in 0 until frames) {
                                for (k in 0 until ch) {
                                    val v = sb.get()
                                    if (k < outChannels) data[size++] = v
                                }
                            }
                        }
                    }
                    c.releaseOutputBuffer(outIdx, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                }
            }
            if (outChannels < 0) throw NoAudioException("The song file is empty.")
            return Pcm(data.copyOf(size), outChannels, sampleRate, max(0L, firstPtsUs) / 1e6)
        } finally {
            try { codec?.stop() } catch (_: Exception) { }
            try { codec?.release() } catch (_: Exception) { }
            extractor.release()
        }
    }
}
