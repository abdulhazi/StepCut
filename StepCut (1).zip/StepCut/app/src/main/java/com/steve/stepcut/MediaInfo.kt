package com.steve.stepcut

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import java.io.File
import java.io.IOException
import kotlin.math.max
import kotlin.math.roundToInt

/** Display size (rotation applied), duration and frame rate of a video. */
data class VideoInfo(val durationSec: Double, val width: Int, val height: Int, val fps: Int)

object MediaInfo {

    fun readVideo(context: Context, uri: Uri): VideoInfo {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(context, uri)
            val durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (w <= 0 || h <= 0) throw IOException("This doesn't look like a video.")
            val rotated = rot % 180 != 0
            return VideoInfo(durMs / 1000.0, if (rotated) h else w, if (rotated) w else h, readFps(context, uri))
        } finally {
            try { r.release() } catch (_: Exception) { }
        }
    }

    private fun readFps(context: Context, uri: Uri): Int {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(context, uri, null)
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (!mime.startsWith("video/") || !f.containsKey(MediaFormat.KEY_FRAME_RATE)) continue
                val fps = try {
                    f.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat()
                } catch (_: Exception) {
                    try { f.getFloat(MediaFormat.KEY_FRAME_RATE) } catch (_: Exception) { 30f }
                }
                return fps.roundToInt().coerceIn(15, 60)
            }
        } catch (_: Exception) {
        } finally {
            ex.release()
        }
        return 30
    }

    /** A frame scaled to at most [maxW] wide. [exact] = nearest frame (slower) instead of nearest keyframe. */
    fun frameAt(context: Context, uri: Uri, timeSec: Double, maxW: Int, info: VideoInfo, exact: Boolean): Bitmap? {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(context, uri)
            val w = minOf(maxW, info.width)
            val h = max(1, (w.toDouble() * info.height / info.width).roundToInt())
            val option = if (exact) MediaMetadataRetriever.OPTION_CLOSEST else MediaMetadataRetriever.OPTION_CLOSEST_SYNC
            return r.getScaledFrameAtTime((timeSec * 1e6).toLong().coerceAtLeast(0L), option, w, h)
        } catch (_: Exception) {
            return null
        } finally {
            try { r.release() } catch (_: Exception) { }
        }
    }

    fun displayName(context: Context, uri: Uri): String {
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) c.getString(idx)?.let { return it }
                }
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment ?: "file"
    }

    /** Copies [file] into Movies/StepCut so it shows in the gallery. */
    fun saveToGallery(context: Context, file: File, displayName: String): Uri {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/StepCut")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values)
            ?: throw IOException("Couldn't create the file in your gallery.")
        try {
            resolver.openOutputStream(uri)?.use { out ->
                file.inputStream().use { it.copyTo(out, 1 shl 20) }
            } ?: throw IOException("Couldn't write to your gallery.")
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }
}
