package com.steve.stepcut

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.common.util.Clock
import androidx.media3.datasource.DataSourceBitmapLoader
import androidx.media3.effect.Presentation
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.mp3.Mp3Extractor
import androidx.media3.extractor.ts.AdtsExtractor
import androidx.media3.transformer.AudioEncoderSettings
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultAssetLoaderFactory
import androidx.media3.transformer.DefaultDecoderFactory
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import java.io.File

data class ExportParams(
    val videoUri: Uri,
    val songUri: Uri,
    /** Part of the video to keep, in video time. */
    val trimStartSec: Double,
    val trimEndSec: Double,
    /** Video time at which the song file's time 0 plays. */
    val lagSec: Double,
    val songDurSec: Double,
    val corners: FloatArray,
    /** Where the zoomed screen goes, or null when zoom is off. */
    val pipRect: NRect?,
    val outW: Int,
    val outH: Int,
    val fps: Int,
    val scoreImage: File?,
    val scoreSec: Double,
    val videoBitrate: Int,
    /** Opening hook: video-time start of the intense part, or null for no hook. */
    val hookStartSec: Double? = null,
    val hookLenSec: Double = 3.0,
    /** Animated title over the start of the main clip, or null. */
    val title: TitleSpec? = null,
    val titleRenderer: TitleRenderer? = null,
    /** Pre-mixed soundtrack (WAV) for the whole video; made by [AudioMixdown]. */
    val soundtrack: File? = null,
)

/** Runs one export with Media3 Transformer. Must be used from the main thread. */
class ExportEngine(private val context: Context) {
    private val handler = Handler(Looper.getMainLooper())
    private var transformer: Transformer? = null
    private var finished = false

    fun start(params: ExportParams, outFile: File, onProgress: (Int) -> Unit, onDone: (Result<File>) -> Unit) {
        val encoderFactory = DefaultEncoderFactory.Builder(context)
            .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(params.videoBitrate).build())
            .setRequestedAudioEncoderSettings(AudioEncoderSettings.Builder().setBitrate(192_000).build())
            .setEnableFallback(true)
            .build()

        // Exact seeking inside MP3s (needed when the song doesn't start at 0:00 of the clip).
        val extractors = DefaultExtractorsFactory()
            .setMp3ExtractorFlags(Mp3Extractor.FLAG_ENABLE_INDEX_SEEKING)
            .setAdtsExtractorFlags(AdtsExtractor.FLAG_ENABLE_CONSTANT_BITRATE_SEEKING)
        val mediaSourceFactory = DefaultMediaSourceFactory(context, extractors)
            .setEnableClippingInMediaPeriod(true)
        val assetLoaderFactory = DefaultAssetLoaderFactory(
            context,
            DefaultDecoderFactory.Builder(context).build(),
            Clock.DEFAULT,
            mediaSourceFactory,
            DataSourceBitmapLoader.Builder(context).build(),
        )

        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                finish(Result.success(outFile))
            }

            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                val msg = "${exportException.errorCodeName}\n" + describe(exportException.cause ?: exportException)
                finish(Result.failure(Exception(msg, exportException)))
            }

            private fun finish(r: Result<File>) {
                if (finished) return
                finished = true
                handler.removeCallbacks(poller)
                transformer = null
                onDone(r)
            }
        }

        val t = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoderFactory)
            .setAssetLoaderFactory(assetLoaderFactory)
            .addListener(listener)
            .build()
        transformer = t
        progressCallback = onProgress
        outFile.parentFile?.mkdirs()
        if (outFile.exists()) outFile.delete()
        t.start(buildComposition(params), outFile.absolutePath)
        handler.postDelayed(poller, 300)
    }

    private var progressCallback: ((Int) -> Unit)? = null
    private val progressHolder = ProgressHolder()
    private val poller = object : Runnable {
        override fun run() {
            val t = transformer ?: return
            if (t.getProgress(progressHolder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                progressCallback?.invoke(progressHolder.progress)
            }
            handler.postDelayed(this, 300)
        }
    }

    fun cancel() {
        handler.post {
            handler.removeCallbacks(poller)
            transformer?.cancel()
            transformer = null
        }
    }

    companion object {
        /** A PIP rectangle that never contains any pixel: zoom turned off. */
        val NO_PIP = NRect(-1f, -1f, -1f, -1f)

        private fun hookFits(p: ExportParams): Boolean {
            val hs = p.hookStartSec ?: return false
            val songFrom = hs - p.lagSec
            return p.hookLenSec > 0.5 && songFrom >= 0 && songFrom + p.hookLenSec <= p.songDurSec - 0.03
        }

        /** The soundtrack, piece by piece, matching the video pieces of [buildComposition]. */
        fun soundtrackPieces(p: ExportParams): List<AudioMixdown.Piece> {
            val pieces = ArrayList<AudioMixdown.Piece>()
            val hook = hookFits(p)
            if (hook) pieces += AudioMixdown.Piece(p.hookStartSec!! - p.lagSec, p.hookLenSec, 0.01, 0.12)
            val clip = p.trimEndSec - p.trimStartSec
            val songFrom = p.trimStartSec - p.lagSec
            // Fade out only when we cut the song before it ends.
            val cutEarly = songFrom + clip < p.songDurSec - 1.0
            pieces += AudioMixdown.Piece(songFrom, clip, if (hook) 0.01 else 0.0, if (cutEarly) 0.6 else 0.0)
            if (p.scoreImage != null && p.scoreSec > 0) pieces += AudioMixdown.Piece(-1e9, p.scoreSec, 0.0, 0.0)
            return pieces
        }

        private fun videoClip(uri: Uri, fromUs: Long, toUs: Long): MediaItem = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionUs(fromUs)
                    .setEndPositionUs(toUs)
                    .build(),
            )
            .build()

        fun buildComposition(p: ExportParams): Composition {
            val vsUs = (p.trimStartSec * 1e6).toLong()
            val veUs = (p.trimEndSec * 1e6).toLong()
            require(veUs - vsUs > 500_000) { "The trimmed part is too short." }
            val soundtrack = requireNotNull(p.soundtrack) { "Soundtrack missing." }
            val pip = p.pipRect ?: NO_PIP
            val videoItems = mutableListOf<EditedMediaItem>()

            // ---- Hook: the most intense few seconds, ending in a white flash ----
            val hasHook = hookFits(p)
            if (hasHook) {
                val hsUs = (p.hookStartSec!! * 1e6).toLong()
                val hlUs = (p.hookLenSec * 1e6).toLong()
                val flash = PipEffect(p.corners, pip, p.outW, p.outH, 0f, 0.14f, p.hookLenSec.toFloat())
                videoItems += EditedMediaItem.Builder(videoClip(p.videoUri, hsUs, hsUs + hlUs))
                    .setRemoveAudio(true)
                    .setEffects(Effects(emptyList<AudioProcessor>(), listOf<Effect>(flash)))
                    .build()
            }

            // ---- Main: the trimmed gameplay (zoomed screen optional, + title) ----
            val mainEffects = ArrayList<Effect>()
            mainEffects += PipEffect(p.corners, pip, p.outW, p.outH, if (hasHook) 0.4f else 0f, 0f, 0f)
            if (p.title != null && p.titleRenderer != null) {
                mainEffects += OverlayEffect(listOf<TextureOverlay>(TitleOverlay(p.titleRenderer, p.title)))
            }
            videoItems += EditedMediaItem.Builder(videoClip(p.videoUri, vsUs, veUs))
                .setRemoveAudio(true)
                .setEffects(Effects(emptyList<AudioProcessor>(), mainEffects))
                .build()

            // ---- Score photo ----
            if (p.scoreImage != null && p.scoreSec > 0) {
                val img = MediaItem.Builder()
                    .setUri(Uri.fromFile(p.scoreImage))
                    .setMimeType(MimeTypes.IMAGE_JPEG)
                    .setImageDurationMs((p.scoreSec * 1000).toLong())
                    .build()
                videoItems += EditedMediaItem.Builder(img)
                    .setFrameRate(p.fps)
                    .setEffects(
                        Effects(
                            emptyList<AudioProcessor>(),
                            listOf<Effect>(Presentation.createForWidthAndHeight(p.outW, p.outH, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)),
                        ),
                    )
                    .build()
            }
            val videoSequence = EditedMediaItemSequence.withVideoFrom(videoItems)

            // ---- Audio: one pre-mixed WAV covering the whole timeline ----
            val audioItem = EditedMediaItem.Builder(
                MediaItem.Builder().setUri(Uri.fromFile(soundtrack)).setMimeType(MimeTypes.AUDIO_WAV).build(),
            ).build()
            val audioSequence = EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_AUDIO)).addItem(audioItem).build()

            return Composition.Builder(videoSequence, audioSequence)
                .setHdrMode(Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL)
                .build()
        }

        /** Readable description of an export error, including the root cause. */
        fun describe(e: Throwable): String {
            val sb = StringBuilder()
            var t: Throwable? = e
            var depth = 0
            val seen = HashSet<Throwable>()
            while (t != null && depth < 6 && seen.add(t)) {
                if (depth > 0) sb.append("\n← ")
                sb.append(t.javaClass.simpleName)
                t.message?.takeIf { it.isNotBlank() }?.let { sb.append(": ").append(it.take(300)) }
                if (t.cause == null) {
                    t.stackTrace.take(4).forEach { sb.append("\n   at ").append(it.className.substringAfterLast('.')).append('.').append(it.methodName).append(':').append(it.lineNumber) }
                }
                t = t.cause
                depth++
            }
            return sb.toString()
        }
    }
}
