package com.steve.stepcut

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** In-place iterative radix-2 complex FFT. Size must be a power of two. */
object Fft {
    private class Table(val cos: DoubleArray, val sin: DoubleArray)

    private val tables = HashMap<Int, Table>()

    @Synchronized
    private fun table(n: Int): Table = tables.getOrPut(n) {
        val half = n / 2
        Table(
            DoubleArray(half) { cos(2.0 * PI * it / n) },
            DoubleArray(half) { sin(2.0 * PI * it / n) },
        )
    }

    fun transform(re: DoubleArray, im: DoubleArray, inverse: Boolean = false) {
        val n = re.size
        require(n == im.size && n > 1 && (n and (n - 1)) == 0) { "FFT size must be a power of two" }
        val t = table(n)
        val sign = if (inverse) 1.0 else -1.0

        // Bit-reversal permutation
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }

        var len = 2
        while (len <= n) {
            val half = len shr 1
            val step = n / len
            var i = 0
            while (i < n) {
                var tw = 0
                for (k in 0 until half) {
                    val wr = t.cos[tw]
                    val wi = sign * t.sin[tw]
                    val a = i + k
                    val b = a + half
                    val vRe = re[b] * wr - im[b] * wi
                    val vIm = re[b] * wi + im[b] * wr
                    re[b] = re[a] - vRe
                    im[b] = im[a] - vIm
                    re[a] += vRe
                    im[a] += vIm
                    tw += step
                }
                i += len
            }
            len = len shl 1
        }

        if (inverse) {
            val inv = 1.0 / n
            for (i in 0 until n) {
                re[i] *= inv
                im[i] *= inv
            }
        }
    }
}
