package com.steve.stepcut

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram
import kotlin.math.max

/**
 * Draws the original frame as the background and, inside [pipRect], a perspective-corrected,
 * zoomed copy of the quad given by [corners] (the game screen). Output size is outW x outH;
 * the background is scaled to cover it.
 */
class PipEffect(
    private val corners: FloatArray,
    private val pipRect: NRect,
    private val outW: Int,
    private val outH: Int,
    /** White flash fading out over the first flashInSec of this clip (0 = none). */
    private val flashInSec: Float = 0f,
    /** White flash building up over the last flashOutSec of this clip (0 = none). */
    private val flashOutSec: Float = 0f,
    private val clipDurSec: Float = 0f,
) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
        PipShaderProgram(useHdr, corners, pipRect, outW, outH, flashInSec, flashOutSec, clipDurSec)
}

private class PipShaderProgram(
    useHdr: Boolean,
    corners: FloatArray,
    pipRect: NRect,
    private val outW: Int,
    private val outH: Int,
    private val flashInSec: Float,
    private val flashOutSec: Float,
    private val clipDurSec: Float,
) : BaseGlShaderProgram(useHdr, 1) {

    private var firstUs = Long.MIN_VALUE

    private val program: GlProgram = try {
        GlProgram(VERTEX_SHADER, FRAGMENT_SHADER)
    } catch (e: GlUtil.GlException) {
        throw VideoFrameProcessingException(e)
    }

    init {
        program.setBufferAttribute(
            "aFramePosition",
            GlUtil.getNormalizedCoordinateBounds(),
            GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE,
        )
        val h = PipGeometry.homography(corners)
        program.setFloatsUniform("uH0", floatArrayOf(h[0], h[1], h[2]))
        program.setFloatsUniform("uH1", floatArrayOf(h[3], h[4], h[5]))
        program.setFloatsUniform("uH2", floatArrayOf(h[6], h[7], h[8]))
        program.setFloatsUniform("uPipRect", floatArrayOf(pipRect.left, pipRect.top, pipRect.right, pipRect.bottom))
        program.setFloatsUniform("uBg", floatArrayOf(1f, 1f, 0f, 0f))
        program.setFloatUniform("uFlash", 0f)
    }

    private fun flashAt(t: Float): Float {
        var f = 0f
        if (flashInSec > 0f && t < flashInSec) f = max(f, 1f - t / flashInSec)
        if (flashOutSec > 0f && clipDurSec > 0f) {
            val start = clipDurSec - flashOutSec
            if (t > start) f = max(f, ((t - start) / flashOutSec).coerceIn(0f, 1f))
        }
        return f * f
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        // Background "cover" mapping in case the output aspect differs from the input.
        val s = max(outW.toFloat() / inputWidth, outH.toFloat() / inputHeight)
        val sx = (outW / s) / inputWidth
        val sy = (outH / s) / inputHeight
        program.setFloatsUniform("uBg", floatArrayOf(sx, sy, (1f - sx) / 2f, (1f - sy) / 2f))
        return Size(outW, outH)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            if (firstUs == Long.MIN_VALUE) firstUs = presentationTimeUs
            program.setFloatUniform("uFlash", flashAt((presentationTimeUs - firstUs) / 1_000_000f))
            program.use()
            program.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            program.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try {
            program.delete()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }
    }

    companion object {
        private const val VERTEX_SHADER = """#version 100
attribute vec4 aFramePosition;
varying vec2 vTexSamplingCoord;
void main() {
  gl_Position = aFramePosition;
  vTexSamplingCoord = vec2(aFramePosition.x * 0.5 + 0.5, aFramePosition.y * 0.5 + 0.5);
}
"""

        // Coordinates: p is the output position with y pointing down (0..1). Source positions
        // are computed with y down too, then flipped back for texture sampling (y up).
        private const val FRAGMENT_SHADER = """#version 100
precision highp float;
uniform sampler2D uTexSampler;
uniform vec4 uPipRect;
uniform vec3 uH0;
uniform vec3 uH1;
uniform vec3 uH2;
uniform vec4 uBg;
uniform float uFlash;
varying vec2 vTexSamplingCoord;
void main() {
  vec2 p = vec2(vTexSamplingCoord.x, 1.0 - vTexSamplingCoord.y);
  vec2 src;
  if (p.x >= uPipRect.x && p.x <= uPipRect.z && p.y >= uPipRect.y && p.y <= uPipRect.w) {
    vec2 uv = (p - uPipRect.xy) / (uPipRect.zw - uPipRect.xy);
    vec3 q = vec3(uv, 1.0);
    float w = dot(uH2, q);
    src = vec2(dot(uH0, q), dot(uH1, q)) / w;
  } else {
    src = p * uBg.xy + uBg.zw;
  }
  src = clamp(src, 0.0, 1.0);
  vec3 col = texture2D(uTexSampler, vec2(src.x, 1.0 - src.y)).rgb;
  gl_FragColor = vec4(mix(col, vec3(1.0), uFlash), 1.0);
}
"""
    }
}
