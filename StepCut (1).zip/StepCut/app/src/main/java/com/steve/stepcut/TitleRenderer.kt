package com.steve.stepcut

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import androidx.media3.effect.CanvasOverlay
import java.util.Random
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * What the title card says. mode: 'S' single, 'D' double, 'C' co-op.
 * template: 0 Neon, 1 Arcade banner, 2 Glitch, 3 Minimal. position: 0 top, 1 middle, 2 bottom.
 */
data class TitleSpec(
    val title: String,
    val artist: String,
    val mode: Char,
    val level: Int,
    val player: String,
    val template: Int,
    val position: Int,
    val accent: Int,
    val art: Bitmap?,
)

class TitleFonts(context: Context) {
    private fun load(ctx: Context, name: String): Typeface =
        try { Typeface.createFromAsset(ctx.assets, "fonts/$name") } catch (_: Exception) { Typeface.DEFAULT_BOLD }

    val russo = load(context, "russo_one.ttf")
    val anton = load(context, "anton.ttf")
    val bebas = load(context, "bebas_neue.ttf")
    val rajBold = load(context, "rajdhani_bold.ttf")
    val rajSemi = load(context, "rajdhani_semibold.ttf")
}

/**
 * Draws one frame of an animated title card. Time t is seconds since the main clip started.
 * All sizes scale with the canvas width (designed at 1080 px wide).
 */
class TitleRenderer(private val fonts: TitleFonts) {

    companion object {
        /** After this time (s) every template has finished animating out. */
        const val END_TIME = 4.15f
        val TEMPLATE_NAMES = arrayOf("Neon", "Arcade", "Glitch", "Minimal")
        private val POSITIONS = floatArrayOf(0.16f, 0.5f, 0.78f)

        fun modeColor(mode: Char): Int = when (mode) {
            'D' -> 0x2EE67A
            'C' -> 0xFFC83D
            else -> 0xFF3D6E
        }

        fun badgeText(s: TitleSpec): String = if (s.mode == 'C') "CO-OP" else "${s.mode}${s.level}"
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val path = Path()
    private val rect = RectF()

    fun draw(c: Canvas, w: Float, h: Float, t: Float, s: TitleSpec) {
        val cy = h * POSITIONS[s.position.coerceIn(0, 2)]
        when (s.template) {
            1 -> drawBanner(c, w, t, s, cy)
            2 -> drawGlitch(c, w, t, s, cy)
            3 -> drawMinimal(c, w, t, s, cy)
            else -> drawNeon(c, w, t, s, cy)
        }
    }

    // ------------------------------------------------------------ helpers

    private fun clamp(x: Float, a: Float = 0f, b: Float = 1f) = max(a, min(b, x))
    private fun prog(t: Float, start: Float, dur: Float) = clamp((t - start) / dur)
    private fun easeOutCubic(x: Float) = 1f - (1f - x).pow(3)
    private fun easeInCubic(x: Float) = x * x * x
    private fun easeOutExpo(x: Float) = if (x >= 1f) 1f else 1f - 2f.pow(-10f * x)
    private fun easeOutBack(x0: Float): Float {
        val s = 1.70158f
        val x = x0 - 1f
        return x * x * ((s + 1) * x + s) + 1f
    }

    private fun argb(a: Float, rgb: Int): Int =
        Color.argb((clamp(a) * 255).toInt(), (rgb shr 16) and 255, (rgb shr 8) and 255, rgb and 255)

    private fun resetPaint(color: Int) {
        paint.reset()
        paint.flags = Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG
        paint.color = color
    }

    private fun setupText(tf: Typeface, size: Float, ls: Float) {
        paint.typeface = tf
        paint.textSize = size
        paint.letterSpacing = ls
    }

    private fun measure(text: String, tf: Typeface, size: Float, ls: Float = 0f): Float {
        resetPaint(Color.WHITE)
        setupText(tf, size, ls)
        return paint.measureText(text)
    }

    private fun fitSize(text: String, tf: Typeface, size: Float, maxW: Float, ls: Float = 0f): Float {
        val w = measure(text, tf, size, ls)
        return if (w <= maxW) size else size * maxW / w
    }

    /** align: 0 left, 1 centre, 2 right. Returns the text width. */
    private fun text(
        c: Canvas, s: String, x0: Float, y: Float, tf: Typeface, size: Float, color: Int,
        ls: Float = 0f, blur: Float = 0f, align: Int = 0,
    ): Float {
        resetPaint(color)
        setupText(tf, size, ls)
        val w = paint.measureText(s)
        val x = when (align) {
            1 -> x0 - w / 2
            2 -> x0 - w
            else -> x0
        }
        if (blur > 0f) paint.maskFilter = BlurMaskFilter(blur * 1.7f, BlurMaskFilter.Blur.NORMAL)
        c.drawText(s, x, y, paint)
        paint.maskFilter = null
        return w
    }

    private fun linear(x0: Float, y0: Float, x1: Float, y1: Float, vararg colors: Int) =
        LinearGradient(x0, y0, x1, y1, colors, null, Shader.TileMode.CLAMP)

    // ------------------------------------------------------------ A: Neon strip

    private fun drawNeon(c: Canvas, w: Float, t: Float, s: TitleSpec, cy: Float) {
        val u = w / 1080f
        val acc = s.accent
        val tIn = 0.15f
        val tOut = 3.6f
        val aOut = 1f - easeInCubic(prog(t, tOut, 0.45f))
        if (aOut <= 0f || t < tIn) return
        val exitDx = w * easeInCubic(prog(t, tOut, 0.45f))
        val pPanel = easeOutExpo(prog(t, tIn, 0.55f))
        val ph = 250 * u
        val top = cy - ph / 2
        val skew = 60 * u
        c.save()
        c.translate(exitDx, 0f)

        val right = -skew + (w * 0.94f + skew) * pPanel
        path.reset()
        path.moveTo(-skew, top + ph); path.lineTo(skew, top); path.lineTo(right + skew, top); path.lineTo(right, top + ph); path.close()
        resetPaint(Color.BLACK)
        paint.shader = linear(0f, top, w, top, argb(0.82f * aOut, 0x05070C), argb(0.55f * aOut, 0x05070C))
        c.drawPath(path, paint)

        resetPaint(argb(aOut, acc))
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 5 * u
        c.drawLine(skew * 0.2f, top, right + skew, top, paint)
        paint.color = argb(0.5f * aOut, acc)
        paint.strokeWidth = 2 * u
        c.drawLine(-skew, top + ph, right, top + ph, paint)

        val x0 = 70 * u
        val badgeW = 210 * u
        val title = s.title.uppercase()
        val tsize = fitSize(title, fonts.russo, 104 * u, w - x0 - badgeW - 70 * u, 0.02f)
        val ty = top + 118 * u
        val pWipe = easeOutCubic(prog(t, tIn + 0.25f, 0.5f))
        c.save()
        c.clipRect(0f, top - 40 * u, x0 + (w - x0) * pWipe, top + ph + 40 * u)
        text(c, title, x0, ty, fonts.russo, tsize, argb(0.9f * aOut, acc), 0.02f, blur = 14 * u)
        text(c, title, x0, ty, fonts.russo, tsize, argb(aOut, 0xFFFFFF), 0.02f)
        c.restore()

        val pSub = easeOutCubic(prog(t, tIn + 0.5f, 0.45f))
        val subDx = (1 - pSub) * -40 * u
        if (s.artist.isNotBlank()) {
            text(c, s.artist.uppercase(), x0 + subDx, ty + 62 * u, fonts.rajSemi, 46 * u, argb(0.85f * aOut * pSub, 0xFFFFFF), 0.12f)
        }
        if (s.player.isNotBlank()) {
            val py = if (s.artist.isNotBlank()) ty + 112 * u else ty + 62 * u
            val pw = text(c, "PLAYED BY ", x0 + subDx, py, fonts.rajSemi, 34 * u, argb(0.6f * aOut * pSub, 0xFFFFFF), 0.15f)
            text(c, s.player.uppercase(), x0 + subDx + pw, py, fonts.rajBold, 34 * u, argb(aOut * pSub, acc), 0.15f)
        }

        val sp = prog(t, tIn + 0.9f, 0.55f)
        if (sp > 0f && sp < 1f) {
            val sx = -200 * u + (w + 400 * u) * sp
            c.save()
            c.clipRect(0f, top, w, top + ph)
            resetPaint(Color.WHITE)
            paint.shader = linear(sx - 120 * u, 0f, sx + 120 * u, 0f, argb(0f, 0xFFFFFF), argb(0.35f * aOut, 0xFFFFFF), argb(0f, 0xFFFFFF))
            c.drawRect(sx - 120 * u, top, sx + 120 * u, top + ph, paint)
            c.restore()
        }

        val bp = prog(t, tIn + 0.45f, 0.5f)
        if (bp > 0f) {
            val sc = easeOutBack(bp)
            val mc = modeColor(s.mode)
            c.save()
            c.translate(w - 70 * u - badgeW / 2, cy)
            c.scale(sc, sc)
            c.rotate(-8f * (1 - bp))
            path.reset()
            val r = 92 * u
            for (i in 0 until 6) {
                val a = Math.toRadians(60.0 * i + 30.0)
                val px = (r * cos(a)).toFloat()
                val py = (r * sin(a)).toFloat()
                if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            path.close()
            resetPaint(argb(0.8f * aOut, mc))
            paint.maskFilter = BlurMaskFilter(16 * u * 1.7f, BlurMaskFilter.Blur.NORMAL)
            c.drawPath(path, paint)
            resetPaint(argb(aOut, 0x0B0D12))
            c.drawPath(path, paint)
            resetPaint(argb(aOut, mc))
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 6 * u
            c.drawPath(path, paint)
            val bt = badgeText(s)
            val bs = fitSize(bt, fonts.russo, 62 * u, 140 * u)
            text(c, bt, 0f, bs * 0.36f, fonts.russo, bs, argb(aOut, 0xFFFFFF), align = 1)
            c.restore()
        }
        c.restore()
    }

    // ------------------------------------------------------------ B: Arcade banner

    private fun drawBanner(c: Canvas, w: Float, t: Float, s: TitleSpec, cy: Float) {
        val u = w / 1080f
        val acc = s.accent
        val tIn = 0.15f
        val tOut = 3.6f
        val po = easeInCubic(prog(t, tOut, 0.4f))
        val aOut = 1f - po
        if (aOut <= 0f || t < tIn) return
        val art = 250 * u
        val ax = 60 * u + art / 2

        // Album art card
        val pa = prog(t, tIn, 0.55f)
        val sc = easeOutBack(pa) * (1 - 0.3f * po)
        c.save()
        c.translate(ax - po * 200 * u, cy)
        c.rotate(-5f + 10f * (1 - easeOutCubic(pa)))
        c.scale(sc, sc)
        resetPaint(argb(0.6f * aOut, 0x000000))
        paint.maskFilter = BlurMaskFilter(20 * u * 1.7f, BlurMaskFilter.Blur.NORMAL)
        rect.set(-art / 2 + 10 * u, -art / 2 + 16 * u, art / 2 + 10 * u, art / 2 + 16 * u)
        c.drawRoundRect(rect, 18 * u, 18 * u, paint)
        resetPaint(argb(aOut, 0xFFFFFF))
        rect.set(-art / 2 - 7 * u, -art / 2 - 7 * u, art / 2 + 7 * u, art / 2 + 7 * u)
        c.drawRoundRect(rect, 22 * u, 22 * u, paint)
        rect.set(-art / 2, -art / 2, art / 2, art / 2)
        val bmp = s.art
        if (bmp != null && !bmp.isRecycled) {
            c.save()
            path.reset()
            path.addRoundRect(rect, 16 * u, 16 * u, Path.Direction.CW)
            c.clipPath(path)
            resetPaint(argb(aOut, 0xFFFFFF))
            // centre-crop the art into the square
            val side = min(bmp.width, bmp.height)
            val src = android.graphics.Rect((bmp.width - side) / 2, (bmp.height - side) / 2, (bmp.width + side) / 2, (bmp.height + side) / 2)
            c.drawBitmap(bmp, src, rect, paint)
            c.restore()
        } else {
            resetPaint(Color.WHITE)
            paint.shader = linear(-art / 2, -art / 2, art / 2, art / 2, argb(aOut, acc), argb(aOut, 0x1A1030))
            c.drawRoundRect(rect, 16 * u, 16 * u, paint)
            val initial = s.title.trim().take(1).uppercase().ifEmpty { "♪" }
            text(c, initial, 0f, 62 * u, fonts.anton, 180 * u, argb(0.9f * aOut, 0xFFFFFF), align = 1)
        }
        c.restore()

        // Title banner sliding in from the right
        val pb = easeOutExpo(prog(t, tIn + 0.2f, 0.6f))
        val bx0 = ax + art / 2 + 40 * u
        val dx = (1 - pb) * (w - bx0) + po * w * 0.6f
        val maxW = w - bx0 - 50 * u
        c.save()
        c.translate(dx, 0f)
        val title = s.title.uppercase()
        val ts = fitSize(title, fonts.anton, 120 * u, maxW)
        text(c, title, bx0 + 5 * u, cy - 5 * u, fonts.anton, ts, argb(0.55f * aOut, 0x000000))
        text(c, title, bx0, cy - 10 * u, fonts.anton, ts, argb(aOut, 0xFFFFFF))
        val barH = 54 * u
        val y0 = cy + 18 * u
        var below = y0
        if (s.artist.isNotBlank()) {
            val artist = s.artist.uppercase()
            val asz = fitSize(artist, fonts.rajBold, 38 * u, maxW - 50 * u, 0.1f)
            val aw = min(maxW, measure(artist, fonts.rajBold, asz, 0.1f) + 44 * u)
            path.reset()
            path.moveTo(bx0, y0); path.lineTo(bx0 + aw + 22 * u, y0); path.lineTo(bx0 + aw, y0 + barH); path.lineTo(bx0, y0 + barH); path.close()
            resetPaint(argb(aOut, acc))
            c.drawPath(path, paint)
            text(c, artist, bx0 + 20 * u, y0 + 40 * u, fonts.rajBold, asz, argb(aOut, 0x0B0B10), 0.1f)
            below = y0 + barH
        }
        if (s.player.isNotBlank()) {
            val ty0 = below + 22 * u
            path.reset()
            path.moveTo(bx0, ty0); path.lineTo(bx0 + 22 * u, ty0 + 13 * u); path.lineTo(bx0, ty0 + 26 * u); path.close()
            resetPaint(argb(aOut, acc))
            c.drawPath(path, paint)
            text(c, s.player.uppercase(), bx0 + 34 * u, below + 48 * u, fonts.rajBold, 34 * u, argb(0.9f * aOut, 0xFFFFFF), 0.12f)
        }
        c.restore()

        // Level badge spinning in at the art's corner
        val pc = prog(t, tIn + 0.45f, 0.5f)
        if (pc > 0f) {
            val mc = modeColor(s.mode)
            val r = 62 * u
            c.save()
            c.translate(ax + art / 2 - 14 * u - po * 200 * u, cy + art / 2 - 14 * u)
            c.rotate(-180f * (1 - easeOutCubic(pc)))
            val bsc = easeOutBack(pc)
            c.scale(bsc, bsc)
            resetPaint(argb(aOut, 0xFFFFFF))
            c.drawCircle(0f, 0f, r + 6 * u, paint)
            resetPaint(argb(aOut, mc))
            c.drawCircle(0f, 0f, r, paint)
            val bt = badgeText(s)
            val bs = fitSize(bt, fonts.russo, 46 * u, 100 * u)
            text(c, bt, 0f, bs * 0.36f, fonts.russo, bs, argb(aOut, 0xFFFFFF), align = 1)
            c.restore()
        }
    }

    // ------------------------------------------------------------ C: Glitch

    private val rnd = Random()

    private fun drawGlitch(c: Canvas, w: Float, t: Float, s: TitleSpec, cy: Float) {
        val u = w / 1080f
        val acc = s.accent
        val tIn = 0.15f
        val tOut = 3.55f
        if (t < tIn || t > tOut + 0.45f) return
        rnd.setSeed((t * 30).toInt() * 7919L)
        val pIn = prog(t, tIn, 0.6f)
        val pOut = prog(t, tOut, 0.45f)
        val burst = (t - 2.2f) * 10f in 0.5f..1.5f
        val intensity = (1 - easeOutCubic(pIn)) + (if (burst) 0.35f else 0f) + easeInCubic(pOut) * 1.2f
        val alpha = clamp(pIn * 3) * (1 - easeInCubic(pOut))
        val title = s.title.uppercase()
        val ts = fitSize(title, fonts.anton, 170 * u, w - 120 * u)
        val baseY = cy + ts * 0.18f

        resetPaint(argb(0.55f * alpha, 0x000000))
        c.drawRect(0f, baseY - ts * 0.95f, w, baseY + 150 * u, paint)

        val slices = 9
        val top = baseY - ts * 0.85f
        val hgt = ts
        for (i in 0 until slices) {
            val y0 = top + hgt * i / slices
            val y1 = top + hgt * (i + 1) / slices
            val r1 = rnd.nextFloat()
            val r2 = rnd.nextFloat()
            val off = if (r2 < 0.6f) (r1 * 2 - 1) * 70 * u * intensity else 0f
            c.save()
            c.clipRect(0f, y0, w, y1)
            val split = (6 + 22 * intensity) * u
            text(c, title, w / 2 + off - split, baseY, fonts.anton, ts, argb(0.85f * alpha, 0x00F0FF), align = 1)
            text(c, title, w / 2 + off + split, baseY, fonts.anton, ts, argb(0.85f * alpha, 0xFF2D8A), align = 1)
            text(c, title, w / 2 + off, baseY, fonts.anton, ts, argb(alpha, 0xFFFFFF), align = 1)
            c.restore()
        }

        resetPaint(argb(0.18f * alpha, 0x000000))
        var y = top
        while (y < baseY + 150 * u) {
            c.drawRect(0f, y, w, y + 2 * u, paint)
            y += 6 * u
        }

        val ps = easeOutCubic(prog(t, tIn + 0.35f, 0.4f)) * (1 - easeInCubic(pOut))
        val sub = s.artist.uppercase()
        val bt = badgeText(s)
        val sw = if (sub.isNotBlank()) measure(sub, fonts.rajBold, 42 * u, 0.12f) else 0f
        val gap = if (sub.isNotBlank()) 24 * u else 0f
        val bw = measure(bt, fonts.russo, 40 * u) + 36 * u
        val total = sw + gap + bw
        val x = w / 2 - total / 2
        val yy = baseY + 80 * u
        if (sub.isNotBlank()) text(c, sub, x, yy, fonts.rajBold, 42 * u, argb(ps, 0xFFFFFF), 0.12f)
        val bx = x + sw + gap
        resetPaint(argb(ps, modeColor(s.mode)))
        c.drawRect(bx, yy - 40 * u, bx + bw, yy + 10 * u, paint)
        text(c, bt, bx + bw / 2, yy - 2 * u, fonts.russo, 40 * u, argb(ps, 0x000000), align = 1)
        if (s.player.isNotBlank()) {
            text(c, "PLAYER: " + s.player.uppercase(), w / 2, yy + 56 * u, fonts.rajSemi, 32 * u, argb(0.7f * ps, acc), 0.2f, align = 1)
        }
    }

    // ------------------------------------------------------------ D: Minimal

    private fun drawMinimal(c: Canvas, w: Float, t: Float, s: TitleSpec, cy: Float) {
        val u = w / 1080f
        val acc = s.accent
        val tIn = 0.15f
        val tOut = 3.6f
        val po = easeInCubic(prog(t, tOut, 0.45f))
        if (t < tIn || po >= 1f) return
        val a = 1f - po
        val p1 = easeOutCubic(prog(t, tIn, 0.6f))
        val title = s.title.uppercase()
        val ts = fitSize(title, fonts.bebas, 150 * u, w - 160 * u, 0.04f)

        resetPaint(Color.BLACK)
        paint.shader = linear(0f, cy - 260 * u, 0f, cy + 220 * u, argb(0f, 0), argb(0.75f * a * p1, 0), argb(0f, 0))
        c.drawRect(0f, cy - 260 * u, w, cy + 220 * u, paint)

        c.save()
        c.clipRect(0f, cy - ts * 0.9f, w, cy + 8 * u)
        val ty = cy + (1 - p1) * ts * 0.9f - po * 30 * u
        text(c, title, w / 2, ty + 4 * u, fonts.bebas, ts, argb(0.6f * a, 0x000000), 0.04f, blur = 8 * u, align = 1)
        text(c, title, w / 2, ty, fonts.bebas, ts, argb(a, 0xFFFFFF), 0.04f, align = 1)
        c.restore()

        val pl = easeOutExpo(prog(t, tIn + 0.3f, 0.7f))
        val half = 300 * u * pl
        resetPaint(argb(a, acc))
        c.drawRect(w / 2 - half, cy + 26 * u, w / 2 + half, cy + 31 * u, paint)

        val p2 = easeOutCubic(prog(t, tIn + 0.5f, 0.5f))
        val parts = ArrayList<String>()
        if (s.artist.isNotBlank()) parts += s.artist.uppercase()
        parts += badgeText(s)
        if (s.player.isNotBlank()) parts += s.player.uppercase()
        val sub = parts.joinToString("   ·   ")
        val ssz = fitSize(sub, fonts.rajBold, 40 * u, w - 100 * u, 0.16f)
        text(c, sub, w / 2, cy + 90 * u + (1 - p2) * 20 * u, fonts.rajBold, ssz, argb(0.95f * a * p2, 0xFFFFFF), 0.16f, align = 1)
    }
}

/**
 * Media3 overlay that draws the animated title over the main clip. Redraws only while the
 * animation runs; afterwards the (cleared) bitmap stays untouched so nothing is re-uploaded.
 */
class TitleOverlay(private val renderer: TitleRenderer, private val spec: TitleSpec) : CanvasOverlay(true) {
    private var firstUs = Long.MIN_VALUE
    private var cleared = false

    override fun onDraw(canvas: Canvas, presentationTimeUs: Long) {
        if (firstUs == Long.MIN_VALUE) firstUs = presentationTimeUs
        val t = (presentationTimeUs - firstUs) / 1_000_000f
        if (t > TitleRenderer.END_TIME) {
            if (!cleared) {
                canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
                cleared = true
            }
            return
        }
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        renderer.draw(canvas, canvas.width.toFloat(), canvas.height.toFloat(), t, spec)
    }
}
