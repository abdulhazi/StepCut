package com.steve.stepcut

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import kotlin.math.max

data class SongEntry(val uri: Uri, val name: String, val size: Long, val modified: Long) {
    val cacheKey: String
        get() {
            val md = MessageDigest.getInstance("SHA-1")
            val bytes = md.digest("$uri|$size|$modified".toByteArray())
            return bytes.joinToString("") { "%02x".format(it) }
        }
}

/** Title/artist/art read from the song file (or guessed from the file name). */
data class SongMeta(val title: String, val artist: String, val art: Bitmap?, val accent: Int)

data class Recognition(
    val entry: SongEntry,
    val fingerprint: Fingerprint,
    val sync: SyncResult,
    /** True when the winner clearly beats every other song. */
    val sure: Boolean,
    val runnerUp: String?,
)

/**
 * The user's folder of clean songs. Each song's fingerprint is computed once and cached,
 * so recognising which song a video contains only takes a few seconds.
 */
class SongLibrary(private val context: Context) {
    private val cacheDir = File(context.filesDir, "fingerprints").apply { mkdirs() }

    fun scan(treeUri: Uri): List<SongEntry> {
        val out = ArrayList<SongEntry>()
        val rootId = DocumentsContract.getTreeDocumentId(treeUri)
        scanDir(treeUri, rootId, 0, out)
        return out.sortedBy { it.name.lowercase() }
    }

    private fun scanDir(treeUri: Uri, docId: String, depth: Int, out: MutableList<SongEntry>) {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
        )
        context.contentResolver.query(children, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: ""
                val mime = c.getString(2) ?: ""
                val size = if (c.isNull(3)) 0L else c.getLong(3)
                val mod = if (c.isNull(4)) 0L else c.getLong(4)
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    if (depth < 4) scanDir(treeUri, id, depth + 1, out)
                } else if (isAudio(name, mime)) {
                    out += SongEntry(DocumentsContract.buildDocumentUriUsingTree(treeUri, id), name, size, mod)
                }
            }
        }
    }

    private fun isAudio(name: String, mime: String): Boolean {
        if (mime.startsWith("audio/")) return true
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext in setOf("mp3", "m4a", "aac", "ogg", "opus", "flac", "wav")
    }

    /** Cached fingerprint, or computes and caches it. */
    fun fingerprint(entry: SongEntry, checkCancelled: () -> Unit): Fingerprint {
        val f = File(cacheDir, entry.cacheKey + ".fp")
        if (f.exists()) {
            try {
                return read(f)
            } catch (_: Exception) {
                f.delete()
            }
        }
        val features = AudioFeatureExtractor.extract(context, entry.uri, checkCancelled) { }
        val fp = AudioSync.fingerprint(features)
        try {
            write(f, fp)
        } catch (_: Exception) {
            f.delete()
        }
        return fp
    }

    fun isCached(entry: SongEntry) = File(cacheDir, entry.cacheKey + ".fp").exists()

    /**
     * Finds which library song plays in the recording. progress(message, fraction 0..1).
     */
    fun recognize(
        rec: Fingerprint,
        entries: List<SongEntry>,
        videoDurSec: Double,
        checkCancelled: () -> Unit,
        progress: (String, Float) -> Unit,
    ): Recognition {
        require(entries.isNotEmpty()) { "Your song folder has no audio files." }
        val coarse = ArrayList<Pair<SongEntry, Double>>()
        entries.forEachIndexed { i, e ->
            checkCancelled()
            val msg = if (isCached(e)) "Comparing with your songs… (${i + 1}/${entries.size})"
            else "Learning new songs… (${i + 1}/${entries.size}) ${e.name}"
            progress(msg, i.toFloat() / entries.size)
            try {
                val fp = fingerprint(e, checkCancelled)
                coarse += e to AudioSync.coarseScore(rec, fp)
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (_: Exception) {
                // unreadable file: skip it
            }
        }
        if (coarse.isEmpty()) throw IllegalStateException("None of the songs in your folder could be read.")
        coarse.sortByDescending { it.second }
        progress("Lining up the best match…", 0.97f)

        class Cand(val e: SongEntry, val fp: Fingerprint, val sync: SyncResult, val score: Double)
        val cands = coarse.take(3).map { (e, _) ->
            val fp = fingerprint(e, checkCancelled)
            val sync = AudioSync.align(rec, fp, videoDurSec)
            Cand(e, fp, sync, sync.correlation * minOf(sync.confidence, 2.0))
        }.sortedByDescending { it.score }
        val best = cands[0]
        val second = cands.getOrNull(1)?.score ?: 0.0
        val sure = best.sync.correlation > 0.06 && best.score > second * 1.8
        return Recognition(best.e, best.fp, best.sync, sure, cands.getOrNull(1)?.e?.name)
    }

    private fun write(f: File, fp: Fingerprint) {
        DataOutputStream(BufferedOutputStream(FileOutputStream(f), 1 shl 16)).use { o ->
            o.writeInt(MAGIC)
            o.writeDouble(fp.startSec)
            o.writeDouble(fp.durationSec)
            o.writeInt(fp.flux.size)
            o.writeInt(fp.size)
            for (g in fp.flux) for (v in g) o.writeFloat(v)
            for (v in fp.onset) o.writeFloat(v)
            for (v in fp.energy) o.writeFloat(v)
        }
    }

    private fun read(f: File): Fingerprint {
        DataInputStream(BufferedInputStream(FileInputStream(f), 1 shl 16)).use { i ->
            if (i.readInt() != MAGIC) throw IllegalStateException("old cache")
            val start = i.readDouble()
            val dur = i.readDouble()
            val groups = i.readInt()
            val n = i.readInt()
            if (groups != AudioSync.GROUPS || n <= 0 || n > 10_000_000) throw IllegalStateException("bad cache")
            val flux = Array(groups) { FloatArray(n) { i.readFloat() } }
            val onset = FloatArray(n) { i.readFloat() }
            val energy = FloatArray(n) { i.readFloat() }
            return Fingerprint(flux, onset, energy, start, dur)
        }
    }

    companion object {
        private const val MAGIC = 0x53434650 // "SCFP" v1

        fun readMeta(context: Context, uri: Uri, fileName: String): SongMeta {
            var title: String? = null
            var artist: String? = null
            var art: Bitmap? = null
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(context, uri)
                title = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.trim()?.takeIf { it.isNotEmpty() }
                artist = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.trim()?.takeIf { it.isNotEmpty() }
                r.embeddedPicture?.let { bytes ->
                    val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                    var sample = 1
                    while (max(opts.outWidth, opts.outHeight) / (sample * 2) >= 600) sample *= 2
                    art = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
                }
            } catch (_: Exception) {
            } finally {
                try { r.release() } catch (_: Exception) { }
            }
            if (title == null) {
                val base = fileName.substringBeforeLast('.').replace('_', ' ').trim()
                val parts = base.split(" - ", limit = 2)
                if (parts.size == 2) {
                    if (artist == null) artist = parts[0].trim()
                    title = parts[1].trim()
                } else {
                    title = base
                }
            }
            return SongMeta(title ?: "", artist ?: "", art, art?.let { accentFrom(it) } ?: DEFAULT_ACCENT)
        }

        const val DEFAULT_ACCENT = 0x35E0C0

        /** A vivid colour from the album art (most common saturated hue). */
        fun accentFrom(bmp: Bitmap): Int {
            val small = Bitmap.createScaledBitmap(bmp, 32, 32, true)
            val bins = FloatArray(12)
            val hsvSum = Array(12) { FloatArray(3) }
            val hsv = FloatArray(3)
            for (y in 0 until 32) for (x in 0 until 32) {
                Color.colorToHSV(small.getPixel(x, y), hsv)
                val weight = hsv[1] * hsv[2]
                if (hsv[1] < 0.35f || hsv[2] < 0.35f) continue
                val b = ((hsv[0] / 30f).toInt()).coerceIn(0, 11)
                bins[b] += weight
                hsvSum[b][0] += hsv[0] * weight
                hsvSum[b][1] += hsv[1] * weight
                hsvSum[b][2] += hsv[2] * weight
            }
            if (small != bmp) small.recycle()
            var best = -1
            for (i in 0 until 12) if (bins[i] > 0f && (best < 0 || bins[i] > bins[best])) best = i
            if (best < 0) return DEFAULT_ACCENT
            val w = bins[best]
            val h = hsvSum[best][0] / w
            // Push it bright and saturated so it reads as an accent on video.
            val s = (hsvSum[best][1] / w).coerceIn(0.65f, 0.9f)
            val v = 1f
            return Color.HSVToColor(floatArrayOf(h, s, v)) and 0xFFFFFF
        }
    }
}
