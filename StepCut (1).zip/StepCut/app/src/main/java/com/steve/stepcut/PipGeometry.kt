package com.steve.stepcut

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min

/** Rectangle in normalised output coordinates (0..1, y pointing down). */
data class NRect(val left: Float, val top: Float, val right: Float, val bottom: Float)

/**
 * widthPct: PIP width as % of the frame width. yPct: vertical position within the free space
 * (0 = top, 100 = bottom). align: 0 left, 1 centre, 2 right. shape: 0 as drawn, 1 16:9, 2 4:3.
 */
data class PipSettings(val widthPct: Int, val yPct: Int, val align: Int, val shape: Int)

object PipGeometry {
    /** Corner order in every FloatArray: TL x,y, TR x,y, BR x,y, BL x,y (normalised, y down). */
    val DEFAULT_CORNERS = floatArrayOf(0.40f, 0.25f, 0.97f, 0.23f, 0.97f, 0.55f, 0.40f, 0.54f)

    /**
     * Projective map from the unit square (u right, v down) onto the quad:
     * (0,0)->TL, (1,0)->TR, (1,1)->BR, (0,1)->BL.
     * Returns [a,b,c,d,e,f,g,h,1]: x = (a u + b v + c) / w, y = (d u + e v + f) / w, w = g u + h v + 1.
     */
    fun homography(c: FloatArray): FloatArray {
        val x0 = c[0].toDouble(); val y0 = c[1].toDouble()
        val x1 = c[2].toDouble(); val y1 = c[3].toDouble()
        val x2 = c[4].toDouble(); val y2 = c[5].toDouble()
        val x3 = c[6].toDouble(); val y3 = c[7].toDouble()
        val dx1 = x1 - x2; val dx2 = x3 - x2; val dx3 = x0 - x1 + x2 - x3
        val dy1 = y1 - y2; val dy2 = y3 - y2; val dy3 = y0 - y1 + y2 - y3
        val den = dx1 * dy2 - dx2 * dy1
        val g = if (abs(den) < 1e-12) 0.0 else (dx3 * dy2 - dx2 * dy3) / den
        val h = if (abs(den) < 1e-12) 0.0 else (dx1 * dy3 - dx3 * dy1) / den
        val a = x1 - x0 + g * x1
        val b = x3 - x0 + h * x3
        val d = y1 - y0 + g * y1
        val e = y3 - y0 + h * y3
        return floatArrayOf(a.toFloat(), b.toFloat(), x0.toFloat(), d.toFloat(), e.toFloat(), y0.toFloat(), g.toFloat(), h.toFloat(), 1f)
    }

    /** Width/height of the quad in pixels of an image of size imgW x imgH. */
    fun quadAspect(c: FloatArray, imgW: Int, imgH: Int): Float {
        fun dist(i: Int, j: Int) = hypot((c[2 * i] - c[2 * j]) * imgW.toDouble(), (c[2 * i + 1] - c[2 * j + 1]) * imgH.toDouble())
        val w = (dist(0, 1) + dist(3, 2)) / 2
        val h = (dist(0, 3) + dist(1, 2)) / 2
        if (h < 1e-6) return 16f / 9f
        return (w / h).toFloat().coerceIn(0.3f, 4f)
    }

    fun pipAspect(settings: PipSettings, corners: FloatArray, imgW: Int, imgH: Int): Float = when (settings.shape) {
        1 -> 16f / 9f
        2 -> 4f / 3f
        else -> quadAspect(corners, imgW, imgH)
    }

    fun pipRect(outW: Int, outH: Int, s: PipSettings, aspect: Float): NRect {
        var w = outW * s.widthPct / 100f
        var h = w / aspect
        if (h > outH) {
            h = outH.toFloat()
            w = h * aspect
        }
        w = min(w, outW.toFloat())
        val x0 = when (s.align) {
            0 -> 0f
            1 -> (outW - w) / 2f
            else -> outW - w
        }
        val y0 = (outH - h) * s.yPct / 100f
        return NRect(x0 / outW, y0 / outH, (x0 + w) / outW, (y0 + h) / outH)
    }
}
