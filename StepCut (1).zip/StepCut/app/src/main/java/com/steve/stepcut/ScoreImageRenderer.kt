package com.steve.stepcut

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Renders the score photo into a full output-sized frame (photo fitted, blurred or black around it). */
object ScoreImageRenderer {

    fun render(context: Context, uri: Uri, outW: Int, outH: Int, blurredBackground: Boolean, outFile: File) {
        val src = ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, uri)) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val w = info.size.width
            val h = info.size.height
            val limit = 3000
            if (max(w, h) > limit) {
                val sc = limit.toFloat() / max(w, h)
                decoder.setTargetSize(max(1, (w * sc).roundToInt()), max(1, (h * sc).roundToInt()))
            }
        }
        val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawColor(Color.BLACK)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        val sw = src.width.toFloat()
        val sh = src.height.toFloat()

        if (blurredBackground) {
            // Cheap but smooth blur: shrink a lot, then scale back up in steps with filtering.
            val cover = max(outW / sw, outH / sh)
            val cw = sw * cover
            val ch = sh * cover
            var small = Bitmap.createScaledBitmap(src, max(2, (cw / 40).roundToInt()), max(2, (ch / 40).roundToInt()), true)
            repeat(2) {
                val up = Bitmap.createScaledBitmap(small, small.width * 3, small.height * 3, true)
                small.recycle()
                small = up
            }
            val dst = RectF((outW - cw) / 2f, (outH - ch) / 2f, (outW + cw) / 2f, (outH + ch) / 2f)
            canvas.drawBitmap(small, null, dst, paint)
            small.recycle()
            canvas.drawColor(Color.argb(110, 0, 0, 0))
        }

        val fit = min(outW / sw, outH / sh) * (if (blurredBackground) 0.94f else 1f)
        val fw = sw * fit
        val fh = sh * fit
        val dst = RectF((outW - fw) / 2f, (outH - fh) / 2f, (outW + fw) / 2f, (outH + fh) / 2f)
        canvas.drawBitmap(src, null, dst, paint)
        src.recycle()

        FileOutputStream(outFile).use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        out.recycle()
    }
}
