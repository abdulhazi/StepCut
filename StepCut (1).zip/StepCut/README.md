# StepCut

Android app that turns a raw Pump It Up gameplay recording into a finished edit:

1. **Pick** the gameplay video and, optionally, a photo of the score. The song is **recognised
   automatically** from your song folder (fingerprints are cached, so it's fast after the first
   time), or you can pick the file by hand.
2. **Auto sync**: the app listens to the video's (noisy) audio and finds exactly where the clean
   song plays (onset-envelope cross-correlation, ~10 ms accuracy). That also gives the trim points:
   the clip starts and ends with the song.
3. **Zoom the screen**: drag 4 corners onto the game screen once; the app remembers them. The
   screen is perspective-corrected and placed as a picture-in-picture over the original shot.
4. **Score** photo is added at the end.
5. **Hook**: the video opens with the most intense few seconds (busiest notes + loudest part of
   the song), then a white flash cuts to the start.
6. **Title**: an animated title card (Neon, Arcade, Glitch, Minimal) with song, artist (from the
   mp3 tags), chart (S/D + level, remembered per song) and your name; colours come from the
   album art.
7. **Export** (720p / 1080p / original, 3 quality levels, size estimate) to Movies/StepCut.

"Quick test" exports a 10-second 720p clip so you can check the sync before the full export.

## Build
Push to GitHub (files or a `StepCut*.zip` at the repo root) and the workflow in
`.github/workflows/android.yml` builds `app-release.apk` (download it from the run's Artifacts).
Every build is signed with the same key (`app/stepcut.keystore`), so new versions install over old ones.

Tech: Kotlin, Media3 Transformer 1.11.1 (custom OpenGL shader for the PIP + flash, Canvas overlay
for the title), minSdk 29. Fonts (OFL): Russo One, Anton, Bebas Neue, Rajdhani.
